#!/usr/bin/env python3
"""Exercise the real Android service against a local fixture, only on an emulator.

Preserves/restores the emulator app's data and proxy. Never contacts the company web,
never prints credentials. Build/install the debug APK and start an emulator first.
"""
import json, os, pathlib, re, subprocess, sys, tempfile, threading, time, html, hashlib
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

ADB = os.environ.get('ADB', '/workspace/toolchains/android-sdk/platform-tools/adb')
PKG = 'vn.duongngang.monitor'

def adb(*args, binary=False):
    result = subprocess.run([ADB, *args], check=True, capture_output=True, timeout=45)
    return result.stdout if binary else result.stdout.decode(errors='replace')

def stop_service():
    # Shell cannot stop the non-exported service directly on every Android image.
    # This helper runs only after the emulator guard, and stops the whole test app.
    adb('shell', 'am', 'force-stop', PKG)

def preferences_xml():
    for attempt in range(8):
        raw = adb('exec-out', 'run-as', PKG, 'cat', 'shared_prefs/monitor.xml', binary=True)
        try:
            ET.fromstring(raw)
            return raw
        except ET.ParseError:
            # Retry an empty ADB read or an atomic settings-file replacement.
            if attempt == 7:
                raise
            time.sleep(0.3)

def metadata():
    root = ET.fromstring(preferences_xml())
    return {e.get('name'): e.get('value', e.text or '') for e in root}

def wait_for(predicate, label, timeout=110):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        state = metadata()
        if predicate(state):
            print('PASS:', label, flush=True)
            return state
        time.sleep(1)
    raise AssertionError(label + ' (status=' + metadata().get('status', '') + ')')

def faults(state):
    return json.loads(state.get('activeFaults', '[]'))

def assert_stopped_outputs():
    pid = adb('shell', 'pidof', PKG).strip()
    assert pid, 'Monitoring process disappeared after stop'
    assert 'pid(' + pid + ')' not in adb('shell', 'dumpsys', 'media.player'), 'Chime player remains allocated'
    assert 'mCurrentVibration=null' in adb('shell', 'dumpsys', 'vibrator'), 'Vibration continues after stop'

def tap_stop_notification(title='101+000'):
    # Exercise the actual System UI action with the Activity in the background.
    adb('shell', 'cmd', 'statusbar', 'expand-notifications')
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        adb('shell', 'uiautomator', 'dump', '/data/local/tmp/rail-notifications.xml')
        root = ET.fromstring(adb('shell', 'cat', '/data/local/tmp/rail-notifications.xml'))
        labels = {'xác nhận'}
        candidates = [group for group in root.iter('node')
                      if any(title in n.get('text', '') for n in group.iter('node'))
                      and any(n.get('text', '').casefold() in labels
                              for n in group.iter('node'))]
        if not candidates:
            collapsed = [group for group in root.iter('node')
                         if any(title in n.get('text', '') for n in group.iter('node'))
                         and any(n.get('resource-id', '').endswith(':id/expand_button')
                                 for n in group.iter('node'))]
            if collapsed:
                header = min(collapsed, key=lambda n: len(list(n.iter())))
                button = next(n for n in header.iter('node')
                              if n.get('resource-id', '').endswith(':id/expand_button'))
                x1, y1, x2, y2 = map(int, re.findall(r'\d+', button.get('bounds')))
                adb('shell', 'input', 'tap', str((x1+x2)//2), str((y1+y2)//2))
                continue
            # Low-priority foreground notifications can be below the visible list.
            adb('shell', 'input', 'swipe', '270', '700', '270', '330', '350')
        # Smallest containing subtree identifies the requested notification, not
        # another notification's identical action elsewhere in the shade.
        group = min(candidates, key=lambda n: len(list(n.iter())), default=ET.Element('empty'))
        for node in group.iter('node'):
            if node.get('text', '').casefold() in labels:
                x1, y1, x2, y2 = map(int, re.findall(r'\d+', node.get('bounds')))
                adb('shell', 'input', 'tap', str((x1+x2)//2), str((y1+y2)//2))
                adb('shell', 'cmd', 'statusbar', 'collapse')
                return
        time.sleep(0.5)
    raise AssertionError('Stop action is not accessible in Android notification shade')

def tap_overview_confirmation():
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        adb('shell', 'uiautomator', 'dump', '/data/local/tmp/rail-overview.xml')
        root = ET.fromstring(adb('shell', 'cat', '/data/local/tmp/rail-overview.xml'))
        cards = [n for n in root.iter('node')
                 if any(c.get('text') == 'CÓ SỰ CỐ' for c in n.iter('node'))
                 and any(c.get('content-desc') == 'XÁC NHẬN lượt cảnh báo hiện tại' for c in n.iter('node'))]
        if cards:
            card = min(cards, key=lambda n: len(list(n.iter())))
            button = next(c for c in card.iter('node')
                          if c.get('content-desc') == 'XÁC NHẬN lượt cảnh báo hiện tại')
            assert button.get('clickable') == 'true', 'Summary confirmation must be an actual button'
            x1, y1, x2, y2 = map(int, re.findall(r'\d+', button.get('bounds')))
            cx1, cy1, cx2, cy2 = map(int, re.findall(r'\d+', card.get('bounds')))
            assert cx1 <= x1 < x2 <= cx2 and cy1 <= y1 < y2 <= cy2, 'Summary button is clipped'
            pathlib.Path('/tmp/rail-0272-summary.png').write_bytes(adb('exec-out', 'screencap', '-p', binary=True))
            adb('shell', 'input', 'tap', str((x1+x2)//2), str((y1+y2)//2))
            return
        time.sleep(0.5)
    raise AssertionError('XÁC NHẬN is missing from the CÓ SỰ CỐ summary card')

AXLE_EXEMPT_POINTS = ('280+500', '307+507', '309+056', '320+445', '338+900', '343+350')

phase = {'value': 0, 'at': int(time.time()), 'manual': False, 'pre_restore': False,
         'supplement': False, 'repeat_barrier': False, 'axles': 0, 'axle_other': False, 'axle_large': False, 'axle_exact': False, 'bell_recovered': False,
         'axle_at': int(time.time()), 'exempt_at': int(time.time())-30}
phase.update(diagram=0, diagram_at=0, diagram_lost_at=0)

class Fixture(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        self.respond((datetime.fromtimestamp(time.time(), timezone.utc).replace(tzinfo=None) + timedelta(hours=7)).date())

    def do_POST(self):
        fields = parse_qs(self.rfile.read(int(self.headers.get('Content-Length', '0'))).decode())
        self.respond(datetime.strptime(fields['date'][0], '%d/%m/%Y').date())

    def respond(self, selected):
        if phase.get('network_down'):
            self.send_response(503)
            self.end_headers()
            return
        if phase.get('slow_read'):
            time.sleep(10)
        # The emulator uses Asia/Ho_Chi_Minh timestamps, independent of the host timezone.
        now = datetime.fromtimestamp(time.time(), timezone.utc).replace(tzinfo=None) + timedelta(hours=7)
        point_options = "<select name='route'><option value='all' selected>-- Tất cả --</option>" + ''.join(
            '<option>Km '+point+'</option>' for point in ('100+000', '101+000')+AXLE_EXEMPT_POINTS+
            ('399+000 (D0)', '400+000', '401+000', '402+000 (D1)')) + '</select>'
        rows = []
        current = dict(phase)
        if selected == now.date():
            te = datetime.fromtimestamp(current['exempt_at'], timezone.utc).replace(tzinfo=None) + timedelta(hours=7)
            for point in AXLE_EXEMPT_POINTS:
                for i in range(7):
                    rows.append((point, 'Khôi phục hệ thống', te+timedelta(seconds=i), False,
                                 [40,40,28 if i == 6 else 37,40,40,40]))
        if selected == now.date() and current['value']:
            t1 = datetime.fromtimestamp(current['at'], timezone.utc).replace(tzinfo=None) + timedelta(hours=7)
            rows += [('101+000', 'Tàu lẻ', t1, False), ('309+056', 'Chuông 2 hỏng', t1, True)]
            if current['repeat_barrier']:
                rows += [('100+000', 'Cần chắn 1 đã hạ', t1-timedelta(seconds=1), False)]
            if current['supplement']:
                rows += [('100+000', 'Tàu lẻ đã qua đường ngang', t1+timedelta(seconds=1), False)]
            if current['manual']:
                rows += [('101+000', 'Ấn nút Phục hồi', t1+timedelta(seconds=3), False)]
            if current['pre_restore']:
                rows += [('101+000', 'Khôi phục hệ thống', t1+timedelta(seconds=2), False)]
            if current['value'] >= 2:
                rows += [('100+000', 'Tàu lẻ', t1-timedelta(seconds=1), False),
                         ('309+056', 'Chuông 2 khôi phục tốt', t1+timedelta(seconds=1), False)]
            if current['value'] >= 3:
                rows += [('100+000', 'Chuông 1 hỏng', t1+timedelta(seconds=2), True)]
            if current['bell_recovered']:
                rows += [('100+000', 'Chuông 1 khôi phục tốt', t1+timedelta(seconds=5), False)]
        if selected == now.date() and current['axles']:
            ta = datetime.fromtimestamp(current['axle_at'], timezone.utc).replace(tzinfo=None) + timedelta(hours=7)
            for i in range(current['axles']):
                rows.append(('100+000','Khôi phục hệ thống',ta+timedelta(seconds=i),False,[40,40,37,40,40,40]))
            if current['axle_other']:
                for i in range(6):
                    rows.append(('100+000','Khôi phục hệ thống',ta+timedelta(seconds=20+i),False,[40,40,40,37,40,40]))
            if current['axle_large']:
                rows.append(('100+000','Khôi phục hệ thống',ta+timedelta(seconds=30),False,[40,40,28,40,40,40]))
            if current['axle_exact']:
                rows.append(('100+000','Khôi phục hệ thống',ta+timedelta(seconds=40),False,[40,40,30,40,40,40]))
        if selected == now.date() and current['diagram']:
            td = datetime.fromtimestamp(current['diagram_at'], timezone.utc).replace(tzinfo=None)+timedelta(hours=7)
            rows += [('400+000', 'Tàu lẻ', td, False),
                     ('400+000', 'Tàu lẻ đã qua đường ngang', td+timedelta(seconds=1), False),
                     ('400+000', 'Khôi phục hệ thống', td+timedelta(seconds=2), False),
                     ('401+000', 'Cần chắn 1 đã hạ', td+timedelta(seconds=3), False),
                     ('401+000', 'Khôi phục hệ thống', td+timedelta(seconds=4), False),
                     ('401+000', 'Mất kết nối giám sát', td, True)]
            if current['diagram'] >= 2:
                tl = datetime.fromtimestamp(current['diagram_lost_at'], timezone.utc).replace(tzinfo=None)+timedelta(hours=7)
                rows += [('400+000', 'Tàu lẻ', tl, False),
                         ('400+000', 'Tàu lẻ đã qua đường ngang', tl+timedelta(seconds=1), False),
                         ('400+000', 'Khôi phục hệ thống', tl+timedelta(seconds=2), False)]
                if current['diagram'] >= 3:
                    rows += [('400+000', 'Tàu lẻ', tl+timedelta(seconds=10), False),
                             ('401+000', 'Tàu lẻ', tl+timedelta(seconds=11), False),
                             ('400+000', 'Tàu lẻ đã qua đường ngang', tl+timedelta(seconds=12), False),
                             ('401+000', 'Tàu lẻ đã qua đường ngang', tl+timedelta(seconds=13), False),
                             ('400+000', 'Khôi phục hệ thống', tl+timedelta(seconds=14), False),
                             ('401+000', 'Khôi phục hệ thống', tl+timedelta(seconds=15), False)]
        if selected == now.date() and current.get('nontrain'):
            tn = datetime.fromtimestamp(current['nontrain_at'], timezone.utc).replace(tzinfo=None)+timedelta(hours=7)
            rows += [('100+000', 'Tàu lẻ', tn, False),
                     ('100+000', 'Tàu lẻ đã qua đường ngang', tn+timedelta(seconds=1), False),
                     ('100+000', 'Khôi phục hệ thống', tn+timedelta(seconds=2), False),
                     ('101+000', 'Ấn nút Duy tu', tn+timedelta(seconds=3), False),
                     ('101+000', 'Ấn nút cảnh báo', tn+timedelta(seconds=4), False),
                     ('101+000', 'Cần chắn 1 đã hạ', tn+timedelta(seconds=5), False),
                     ('101+000', 'Khôi phục hệ thống', tn+timedelta(seconds=6), False),
                     ('101+000', 'Cần chắn 1 đã nâng', tn+timedelta(seconds=7), False),
                     ('101+000', 'Cần chắn 2 đã nâng', tn+timedelta(seconds=7), False),
                     ('101+000', 'Ấn nút Phục hồi', tn+timedelta(seconds=8), False),
                     ('101+000', 'Tàu lẻ', tn+timedelta(seconds=10), False)]
            if current.get('nontrain_next'):
                tn2 = datetime.fromtimestamp(current['nontrain_next'], timezone.utc).replace(tzinfo=None)+timedelta(hours=7)
                rows += [('101+000', 'Tàu lẻ', tn2, False)]
        if selected == now.date() and current.get('audio_stage'):
            ta = datetime.fromtimestamp(current['audio_at'], timezone.utc).replace(tzinfo=None)+timedelta(hours=7)
            rows += [('101+000','Cầu chì 50A bị đứt',ta,False), ('101+000','nguồn DC > 29v',ta,True)]
            if current['audio_stage'] >= 2:
                rows += [('101+000','Cầu chì 50A khôi phục tốt',ta+timedelta(seconds=2),False),
                         ('101+000','Nguồn 24V khôi phục tốt',ta+timedelta(seconds=3),False),
                         ('101+000','Chuông 1 hỏng',datetime.fromtimestamp(current['bell_at'],timezone.utc).replace(tzinfo=None)+timedelta(hours=7),True)]
            if current['audio_stage'] >= 3:
                ts=datetime.fromtimestamp(current['silent_at'],timezone.utc).replace(tzinfo=None)+timedelta(hours=7)
                rows += [('101+000','Chuông 1 khôi phục tốt',ts,False),('101+000','Đèn 1 hỏng',ts,True)]
        table = "<table id='FixtureGdata'>"
        for entry in reversed(rows):
            point, text, at, red = entry[:4]
            counts = entry[4] if len(entry) > 4 else []
            table += f"<tr><td>Km {point}</td><td><font color={'red' if red else 'blue'}>{html.escape(text)}</font></td><td>{selected:%d/%m}</td><td>{at:%H:%M:%S}</td>" + ''.join(f'<td>{n}</td>' for n in counts) + '</tr>'
        body = (f"<form method='post' action='/'><h1>BÁO CÁO ĐƯỜNG NGANG CBTĐ</h1><input name='date' value='{selected:%d/%m/%Y}'>"
                + point_options + table + '</table></form>').encode()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=UTF-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def run_diagram_checks():
    def diagram_visits(state):
        return [row for row in json.loads(state.get('travelState','[]')) if row[1] in ('400+000','401+000')]
    phase.update(diagram=1, diagram_at=int(time.time())-10)
    sparse = wait_for(lambda s: diagram_visits(s) and all(row[7] for row in diagram_visits(s))
                      and any(row[0].startswith('travel:motion:') for row in diagram_visits(s))
                      and any(row[2].removeprefix('Km ').strip()=='401+000' and row[3]=='Mất kết nối giám sát' for row in faults(s)),
                      'sparse barrier and restoration clear diagram while keeping actual network fault')
    diagram_alarm = int(sparse.get('lastAlarm','0'))
    phase.update(diagram=2, diagram_lost_at=int(time.time())-10)
    wait_for(lambda s: any(not row[7] and row[1]=='400+000' for row in diagram_visits(s)),
             'wholly missing destination remains visible until another confirmed train')
    phase['diagram'] = 3
    recovered = wait_for(lambda s: diagram_visits(s) and all(row[7] for row in diagram_visits(s))
                         and any(row[2].removeprefix('Km ').strip()=='401+000' and row[3]=='Mất kết nối giám sát' for row in faults(s)),
                         'next complete train heals lost visit and retains original network fault')
    assert int(recovered.get('lastAlarm','0')) == diagram_alarm, 'Diagram resync alone must not sound again'
    print('PASS: diagram recovery does not replay hardware alarm',flush=True)


def main():
    assert adb('shell', 'getprop', 'ro.kernel.qemu').strip() == '1', 'Emulator required; physical phones are refused'
    assert adb('get-serialno').strip().startswith('emulator-'), 'Use a dedicated emulator'
    target_apk = pathlib.Path(__file__).resolve().parent.parent/'app/build/outputs/apk/debug/app-debug.apk'
    installed_apk = adb('shell','pm','path',PKG).strip().removeprefix('package:')
    installed_hash = adb('shell','sha256sum',installed_apk).split()[0]
    assert hashlib.sha256(target_apk.read_bytes()).hexdigest()==installed_hash, 'Install the current built APK before service checks'
    previous = metadata()
    previous_running = previous.get('running') == 'true'
    old_proxy = adb('shell', 'settings', 'get', 'global', 'http_proxy').strip()
    stop_service()
    adb('shell', 'am', 'force-stop', PKG)
    server = ThreadingHTTPServer(('127.0.0.1', 8888), Fixture)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    with tempfile.TemporaryDirectory(prefix='rail-monitor-test-') as temp:
        folder = pathlib.Path(temp)
        os.chmod(folder, 0o700)
        original_prefs = preferences_xml()
        pref_root = ET.fromstring(original_prefs)
        for node in pref_root:
            if node.get('name') == 'running':
                node.set('value', 'true' if previous_running else 'false')
        (folder/'original.xml').write_bytes(ET.tostring(pref_root, encoding='utf-8'))
        original_db = subprocess.run([ADB, 'exec-out', 'run-as', PKG, 'cat', 'databases/events.db'], capture_output=True, timeout=30)
        if original_db.returncode == 0:
            (folder/'original.db').write_bytes(original_db.stdout)
        root = ET.Element('map')
        ET.SubElement(root, 'string', name='url').text = 'http://10.0.2.2:8888/'
        ET.SubElement(root, 'string', name='user').text = 'local-fixture'
        for name, value in [('demoUi', 'false'), ('running', 'true'), ('sound', 'true')]:
            ET.SubElement(root, 'boolean', name=name, value=value)
        ET.SubElement(root, 'int', name='interval', value='30')  # Self-trigger detection intentionally runs only at the real 30-second setting.
        if '--reconnect-only' in sys.argv or '--reconnect-ui-only' in sys.argv:
            next(n for n in root if n.get('name') == 'sound').set('value', 'false')
            ET.SubElement(root, 'string', name='alertMode').text = 'silent'
        (folder/'fixture.xml').write_bytes(ET.tostring(root, encoding='utf-8'))
        def install(local, remote):
            adb('push', str(local), '/data/local/tmp/rail-e2e-file')
            adb('shell', 'run-as', PKG, 'cp', '/data/local/tmp/rail-e2e-file', remote)
        try:
            install(folder/'fixture.xml', 'shared_prefs/monitor.xml')
            adb('shell', 'run-as', PKG, 'rm', '-f', 'databases/events.db')
            adb('shell', 'settings', 'put', 'global', 'http_proxy', ':0')
            adb('shell', 'am', 'start', '-n', PKG+'/.MainActivity')
            empty = wait_for(lambda s: int(s.get('lastSuccess','0')) > 0, 'initial snapshot accepted silently')
            assert int(empty.get('lastAlarm', '0')) == 0, 'Empty snapshot must not sound'
            assert not faults(empty), 'Exempt axle reports must not create faults'
            print('PASS: six qualifying errors and one large deviation at all six exempt points remain silent', flush=True)
            if '--reconnect-only' in sys.argv or '--reconnect-ui-only' in sys.argv:
                phase.update(audio_stage=1, audio_at=int(time.time())-1)
                populated = wait_for(lambda s: len(faults(s)) == 2, 'cache contains unresolved faults before outage')
                phase['network_down'] = True
                failed = wait_for(lambda s: s.get('connectionLost') == 'true'
                    and s.get('connectionRetrying') == 'false', 'failed request records connection loss')
                if '--reconnect-ui-only' in sys.argv:
                    failed_again = failed
                else:
                    adb('shell', 'input', 'keyevent', 'KEYCODE_HOME')
                    retry = wait_for(lambda s: int(s.get('lastConnectionAttempt','0')) > int(failed['lastConnectionAttempt']),
                        'background automatically retries after outage', timeout=180)
                    assert int(retry['lastConnectionAttempt']) - int(failed['lastConnectionAttempt']) >= 119500, 'Retry occurred before two minutes'
                    assert retry.get('lastSuccess') == failed.get('lastSuccess'), 'Outage overwrote last good timestamp'
                    assert faults(retry) == faults(populated), 'Outage erased cached faults'
                    completed = wait_for(lambda s: s.get('connectionRetrying') == 'false', 'failed background retry completes')
                    phase['network_down'] = False
                    recovered = wait_for(lambda s: s.get('connectionLost') == 'false'
                        and int(s.get('lastSuccess','0')) > int(failed['lastSuccess']),
                        'automatic background retry recovers without opening Activity', timeout=180)
                    assert int(recovered['lastConnectionAttempt']) - int(completed['lastConnectionAttempt']) >= 119500
                    normal = wait_for(lambda s: int(s.get('lastConnectionAttempt','0')) > int(recovered['lastConnectionAttempt']),
                        'normal thirty-second polling resumes', timeout=85)
                    gap = int(normal['lastConnectionAttempt']) - int(recovered['lastConnectionAttempt'])
                    assert 29500 <= gap < 85000, 'Recovered polling did not return to thirty seconds'
                    phase['network_down'] = True
                    failed_again = wait_for(lambda s: s.get('connectionLost') == 'true'
                        and s.get('connectionRetrying') == 'false', 'another outage exposes manual reconnect')
                adb('shell', 'am', 'start', '-n', PKG+'/.MainActivity')
                deadline = time.monotonic() + 35
                button = None
                while time.monotonic() < deadline:
                    adb('shell', 'uiautomator', 'dump', '/data/local/tmp/rail-reconnect.xml')
                    ui = ET.fromstring(adb('shell', 'cat', '/data/local/tmp/rail-reconnect.xml'))
                    button = next((n for n in ui.iter('node') if n.get('text') == 'Kết nối lại'), None)
                    if button is not None: break
                    time.sleep(0.5)
                assert button is not None, 'Reconnect button did not appear on Overview'
                warning = next(n for n in ui.iter('node') if n.get('text') == 'Mất kết nối')
                x1,y1,x2,y2 = map(int,re.findall(r'\d+',button.get('bounds')))
                assert int(re.findall(r'\d+',warning.get('bounds'))[1]) >= y2, 'Warning must be below reconnect button'
                summary = next(n for n in ui.iter('node') if n.get('text') == 'CẦN KIỂM TRA CẬP NHẬT')
                diagram = next(n for n in ui.iter('node') if n.get('content-desc','').startswith('Toàn tuyến, gồm'))
                assert y1 > int(re.findall(r'\d+',summary.get('bounds'))[3]), 'Connection strip must follow fault summary'
                assert int(re.findall(r'\d+',warning.get('bounds'))[3]) <= int(re.findall(r'\d+',diagram.get('bounds'))[1]), 'Connection strip must precede train diagram'
                pathlib.Path('/tmp/rail-reconnect.png').write_bytes(adb('exec-out','screencap','-p',binary=True))
                phase['network_down'] = False
                adb('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2))
                manual = wait_for(lambda s: s.get('connectionLost') == 'false'
                    and int(s.get('lastSuccess','0')) > int(failed_again['lastSuccess']), 'manual reconnect succeeds immediately')
                assert int(manual['lastConnectionAttempt']) - int(failed_again['lastConnectionAttempt']) < 90000, 'Button did not bypass pending two-minute timer'
                assert faults(manual) == faults(populated) and manual.get('running') == 'true'
                deadline = time.monotonic() + 10
                while time.monotonic() < deadline:
                    adb('shell','uiautomator','dump','/data/local/tmp/rail-reconnected.xml')
                    ui = ET.fromstring(adb('shell','cat','/data/local/tmp/rail-reconnected.xml'))
                    if any(n.get('text','').startswith('Đã kết nối') for n in ui.iter('node')): break
                assert not any(n.get('text') in ('Kết nối lại','Mất kết nối') for n in ui.iter('node')), 'Recovered UI still shows connection loss'
                assert any(n.get('text','').startswith('Đã kết nối') for n in ui.iter('node')), 'Online status must remain visible'
                phase['slow_read'] = True
                loading = wait_for(lambda s: s.get('dataLoading') == 'true', 'real data read publishes loading progress', timeout=85)
                deadline = time.monotonic() + 8
                while time.monotonic() < deadline:
                    adb('shell','uiautomator','dump','/data/local/tmp/rail-loading.xml')
                    ui = ET.fromstring(adb('shell','cat','/data/local/tmp/rail-loading.xml'))
                    if any(n.get('text') == 'Đang tải dữ liệu…' for n in ui.iter('node')): break
                assert any(n.get('text') == 'Đang tải dữ liệu…' for n in ui.iter('node')), 'Loading text is missing'
                assert any(n.get('class') == 'android.widget.ProgressBar' for n in ui.iter('node')), 'Loading indicator is missing'
                pathlib.Path('/tmp/rail-loading.png').write_bytes(adb('exec-out','screencap','-p',binary=True))
                phase['slow_read'] = False
                wait_for(lambda s: s.get('dataLoading') == 'false'
                    and s.get('connectionLost') == 'false'
                    and int(s.get('lastSuccess','0')) > int(loading['lastSuccess']), 'loading progress ends after successful read', timeout=85)
                if '--reconnect-ui-only' not in sys.argv:
                    print('Measured retry/normal/manual gaps (ms):',
                          int(retry['lastConnectionAttempt']) - int(failed['lastConnectionAttempt']),
                          gap, int(manual['lastConnectionAttempt']) - int(failed_again['lastConnectionAttempt']), flush=True)
                print('Reconnect background and UI checks passed', flush=True)
                return
            if '--notification-stop-only' in sys.argv:
                adb('shell', 'input', 'keyevent', 'KEYCODE_HOME')
                phase.update(audio_stage=1, audio_at=int(time.time())-1)
                voiced = wait_for(lambda s: len(faults(s)) == 2
                    and s.get('voiceStatus', '').startswith('Đang đọc'),
                    'background service begins reading two new faults')
                tap_stop_notification()
                stopped = wait_for(lambda s: s.get('voiceStatus') == 'Đã dừng giọng đọc',
                    'notification action stops current voice batch without opening app')
                assert_stopped_outputs()
                assert stopped.get('running') == 'true' and stopped.get('sound') == 'true'
                assert stopped.get('alertMode', 'voice') == voiced.get('alertMode', 'voice')
                assert faults(stopped) == faults(voiced), 'Stopping audio must preserve active faults'
                after = wait_for(lambda s: int(s.get('lastSuccess', '0')) > int(stopped['lastSuccess']),
                    'monitoring continues after stop action')
                assert after.get('lastAlarm') == stopped.get('lastAlarm'), 'Empty poll replayed stopped batch'
                assert after.get('voiceStatus') == 'Đã dừng giọng đọc'
                assert 'vn.duongngang.monitor/.MainActivity' not in '\n'.join(
                    line for line in adb('shell', 'dumpsys', 'activity', 'activities').splitlines()
                    if 'mResumedActivity' in line), 'Stop action opened Activity'
                notes = adb('shell', 'dumpsys', 'notification', '--noredact')
                assert 'channel=monitor' in notes and 'channel=faults_alerts_027' in notes
                adb('shell', 'am', 'start', '-n', PKG+'/.MainActivity')
                warm = wait_for(lambda s: int(s.get('lastSuccess', '0')) > int(after['lastSuccess']),
                    'reopening Activity keeps monitoring')
                assert warm.get('lastAlarm') == stopped.get('lastAlarm'), 'Activity reopen replayed old faults'
                stop_service()  # Abrupt process loss preserves data and running=true.
                adb('shell', 'am', 'start', '-n', PKG+'/.MainActivity')
                restarted = wait_for(lambda s: int(s.get('lastSuccess', '0')) > int(warm['lastSuccess']),
                    'monitoring resumes after process restart')
                settled = wait_for(lambda s: int(s.get('lastSuccess', '0')) > int(restarted['lastSuccess']),
                    'first and next polls complete after process restart')
                assert settled.get('lastAlarm') == stopped.get('lastAlarm'), 'Process restart replayed old faults'
                assert faults(settled) == faults(stopped), 'Reopening changed existing faults'
                assert settled.get('running') == 'true' and settled.get('sound') == 'true'
                assert_stopped_outputs()
                print('PASS: warm reopen and process restart preserve faults without replaying audio', flush=True)
                adb('shell', 'input', 'keyevent', 'KEYCODE_HOME')
                phase.update(audio_stage=2, bell_at=int(time.time())-1)
                fresh = wait_for(lambda s: any(row[3] == 'Chuông 1 hỏng' for row in faults(s))
                    and int(s.get('lastAlarm', '0')) > int(stopped['lastAlarm'])
                    and s.get('voiceStatus', '').startswith('Đang đọc'),
                    'new fault sounds and speaks normally after stopping previous batch')
                adb('shell', 'am', 'start', '-n', PKG+'/.MainActivity')
                tap_overview_confirmation()
                confirmed = wait_for(lambda s: s.get('voiceStatus') == 'Đã dừng giọng đọc',
                    'overview confirmation stops current batch')
                assert faults(confirmed) == faults(fresh), 'Summary confirmation cleared faults'
                assert confirmed.get('running') == 'true' and confirmed.get('sound') == 'true'
                assert_stopped_outputs()
                print('Notification stop service checks passed', flush=True)
                return
            if '--audio-modes-only' in sys.argv:
                phase.update(audio_stage=1,audio_at=int(time.time())-1)
                voiced=wait_for(lambda s: any(row[3]=='Cầu chì 50A bị đứt' for row in faults(s))
                    and any(row[3]=='nguồn DC > 29v' for row in faults(s))
                    and int(s.get('lastAlarm','0'))>0 and s.get('voiceStatus','').startswith('Đang đọc'),
                    'voice mode reads real service alerts, including uncolored fifty-ampere fuse')
                def select_mode(mode, day=''):
                    stop_service()
                    state=ET.fromstring(preferences_xml())
                    for key in ['alertMode','sound','running','monitorDate','historyReadDay','historyReadAt']:
                        for child in list(state):
                            if child.get('name')==key: state.remove(child)
                    ET.SubElement(state,'string',name='alertMode').text=mode
                    ET.SubElement(state,'boolean',name='sound',value='false' if mode=='silent' else 'true')
                    ET.SubElement(state,'boolean',name='running',value='true')
                    ET.SubElement(state,'string',name='monitorDate').text=day
                    file=folder/'audio-mode.xml';file.write_bytes(ET.tostring(state,encoding='utf-8'))
                    install(file,'shared_prefs/monitor.xml')
                    adb('shell','am','start','-n',PKG+'/.MainActivity')
                phase.update(audio_stage=2,bell_at=int(time.time())-1)
                select_mode('bell')
                bell=wait_for(lambda s: any(row[3]=='Chuông 1 hỏng' for row in faults(s))
                    and int(s.get('lastAlarm','0'))>int(voiced['lastAlarm'])
                    and s.get('voiceStatus')=='Chế độ chỉ chuông',
                    'bell-only mode plays while fuse and DC recoveries are processed')
                assert all(row[3] not in ('Cầu chì 50A bị đứt','nguồn DC > 29v') for row in faults(bell))
                print('PASS: exact fuse and DC/24V recovery names close only corresponding power alerts',flush=True)
                phase.update(audio_stage=3,silent_at=int(time.time())-1)
                select_mode('silent')
                silent=wait_for(lambda s: any(row[3]=='Đèn 1 hỏng' for row in faults(s))
                    and s.get('voiceStatus')=='Đã tắt âm thanh cảnh báo', 'silent mode retains visual fault and notification')
                assert silent.get('lastAlarm')==bell.get('lastAlarm'),'Silent mode must not start an audible batch'
                assert 'channel=faults_silent' in adb('shell','dumpsys','notification','--noredact')
                yesterday=(datetime.now(timezone.utc)+timedelta(hours=7)).date()-timedelta(days=1)
                select_mode('voice',yesterday.isoformat())
                history=wait_for(lambda s:s.get('historyReadDay')==yesterday.isoformat(),
                    'historical read completes with voice enabled but no audible alert')
                assert history.get('lastAlarm')==bell.get('lastAlarm'),'History must not start speech or chimes'
                print('5 audio-mode service checks passed',flush=True)
                return
            if '--nontrain-only' in sys.argv:
                operator_start = int(time.time())+1
                phase.update(nontrain=True, nontrain_at=operator_start)
                accepted = wait_for(lambda s: int(s.get('lastSuccess','0')) > (operator_start+40)*1000,
                                    'completed upstream proof survives a whole local operation series over two polls')
                assert not faults(accepted), 'Local actions must not create a false self-trigger'
                assert json.loads(accepted.get('pendingSelf','{}')) == {}, 'No delayed false candidate may remain'
                assert int(accepted.get('lastAlarm','0')) == 0, 'Valid train must not cause false audible alarm'
                print('PASS: operator actions do not discard the completed incoming train, including after the grace poll',flush=True)
                next_train = int(time.time())+1
                phase.update(nontrain_next=next_train)
                unsupported = wait_for(lambda s: int(s.get('lastSuccess','0')) > (next_train+30)*1000
                                       and any(row[3]=='Nghi tự kích' and int(row[1])==next_train*1000
                                               for row in faults(s))
                                       and int(s.get('lastAlarm','0')) > 0,
                                       'the next unsupported real arrival cannot reuse the earlier source')
                assert all(int(row[1]) != (operator_start+10)*1000 for row in faults(unsupported)), 'The first valid arrival must remain supported'
                assert int(unsupported.get('lastAlarm','0')) > 0, 'A new real unsupported arrival must retain incident sound'
                print('PASS: one proof supports only one real arrival; a later unsupported train is still warned',flush=True)
                return
            if '--retention-only' in sys.argv:
                local_day = (datetime.now(timezone.utc) + timedelta(hours=7)).date()
                retention_start = datetime.combine(local_day - timedelta(days=14), datetime.min.time(),
                                                   timezone(timedelta(hours=7)))
                assert int(empty.get('retentionCutoff', '0')) == int(retention_start.timestamp()*1000), 'Expected 15-day Vietnamese retention floor'
                assert int(empty.get('retentionPreparedAt', '0')) == int(empty['retentionCutoff']), 'Expected persisted checkpoint barrier before pruning'
                print('PASS: foreground poll prepares durable 30-date retention while accepting current reports silently', flush=True)
                return
            if '--diagram-only' in sys.argv:
                run_diagram_checks()
                print('4 diagram monitoring checks passed', flush=True)
                return
            phase.update(value=1, at=int(time.time())-3)
            wait_for(lambda s: any(row[3]=='Chuông 2 hỏng' for row in faults(s)) and int(s.get('lastAlarm','0'))>0, 'original red bell message becomes active with app-owned audible playback')
            wait_for(lambda s: any(row[3]=='Nghi tự kích' for row in faults(s)), 'self-trigger confirmed after elapsed grace')
            notes=adb('shell','dumpsys','notification','--noredact')
            assert re.search(r'Notification\(channel=faults_sound', notes), 'Expected sound-channel notification'
            print('PASS: active alerts use sound channel', flush=True)
            before_proof_alarm = int(metadata().get('lastAlarm', '0'))
            phase['supplement'] = True
            proved = wait_for(lambda s: not any(row[3]=='Nghi tự kích' for row in faults(s))
                             and any(row[3]=='Chuông 2 hỏng' for row in faults(s))
                             and not any(row[10] for row in json.loads(s.get('travelState','[]'))),
                             'late same-direction upstream passage removes inference while retaining original bell fault')
            assert int(proved.get('lastAlarm','0')) == before_proof_alarm, 'Evidence correction must not sound a new fault'
            assert not any(row[10] for row in json.loads(proved.get('travelState','[]'))), 'Disproved self classification must leave the diagram replay'
            print('PASS: evidence correction cancels only inferred classification without replaying alarm',flush=True)
            phase.update(supplement=False, repeat_barrier=True, at=int(time.time())-3)
            wait_for(lambda s: any(row[3]=='Nghi tự kích' for row in faults(s)),
                     'a new unsupported visit is still suspected despite repeated movement in the earlier used visit')
            phase['manual'] = True
            cleared = wait_for(lambda s: len(faults(s))==1 and faults(s)[0][3]=='Chuông 2 hỏng'
                               and all(row[7] for row in json.loads(s.get('travelState','[]'))),
                               'manual recovery clears self-trigger and diagram while keeping original bell fault')
            assert any(row[10] for row in json.loads(cleared['travelState'])), 'Expected persisted self-trigger classification'
            print('PASS: manually completed self-trigger retains its classification and completion record', flush=True)
            # Backfill an earlier generic restore: it must not hide the later manual reset
            # when deciding which completed inference evidence to retain at longer intervals.
            phase['pre_restore'] = True
            stop_service()
            state_root = ET.fromstring(preferences_xml())
            for node in state_root:
                if node.get('name') == 'interval': node.set('value', '120')
                if node.get('name') == 'running': node.set('value', 'true')
            (folder/'manual-disabled.xml').write_bytes(ET.tostring(state_root, encoding='utf-8'))
            install(folder/'manual-disabled.xml', 'shared_prefs/monitor.xml')
            adb('shell', 'am', 'start', '-n', PKG+'/.MainActivity')
            wait_for(lambda s: int(s.get('lastSuccess','0')) > int(cleared['lastSuccess'])
                     and all(row[7] for row in json.loads(s.get('travelState','[]')))
                     and any(row[10] for row in json.loads(s.get('travelState','[]'))),
                     'switching to 2-minute polling keeps manually reset self interval off')
            stop_service()
            state_root = ET.fromstring(preferences_xml())
            for node in state_root:
                if node.get('name') == 'interval': node.set('value', '30')
                if node.get('name') == 'running': node.set('value', 'true')
            (folder/'manual-enabled.xml').write_bytes(ET.tostring(state_root, encoding='utf-8'))
            install(folder/'manual-enabled.xml', 'shared_prefs/monitor.xml')
            phase['value']=2
            adb('shell', 'am', 'start', '-n', PKG+'/.MainActivity')
            wait_for(lambda s: not faults(s) and json.loads(s.get('pendingSelf','{}'))=={}, 'late upstream evidence removes inference; explicit bell recovery clears bell')
            last_audible = int(metadata().get('lastAlarm', '0'))
            # Change only the global sound preference; restart the same account to prove no replay.
            stop_service();adb('shell','am','force-stop',PKG)
            state_root=ET.fromstring(preferences_xml())
            for node in state_root:
                if node.get('name')=='sound':node.set('value','false')
                if node.get('name')=='running':node.set('value','true')
            (folder/'silent.xml').write_bytes(ET.tostring(state_root,encoding='utf-8'))
            install(folder/'silent.xml','shared_prefs/monitor.xml')
            adb('shell','am','start','-n',PKG+'/.MainActivity')
            phase['value']=3
            wait_for(lambda s:any(row[3]=='Chuông 1 hỏng' for row in faults(s)), 'subsequent fault stays red with global sound disabled')
            notes=adb('shell','dumpsys','notification','--noredact')
            assert re.search(r'Notification\(channel=faults_silent',notes),'Expected silent-channel notification'
            print('PASS: later fault uses silent channel', flush=True)
            assert int(metadata().get('lastAlarm', '0')) == last_audible, 'Global mute must also suppress the app-owned player'
            print('PASS: global mute suppresses app-owned audible playback', flush=True)
            # Reopen with an already active fault: this was the reported silent-start bug.
            stop_service()
            state_root = ET.fromstring(preferences_xml())
            for node in state_root:
                if node.get('name') in ('sound', 'running'):
                    node.set('value', 'true')
                if node.get('name') == 'interval':
                    node.set('value', '120')
            (folder/'audible-start.xml').write_bytes(ET.tostring(state_root, encoding='utf-8'))
            install(folder/'audible-start.xml', 'shared_prefs/monitor.xml')
            adb('shell', 'am', 'start', '-n', PKG+'/.MainActivity')
            wait_for(lambda s: any(row[3]=='Chuông 1 hỏng' for row in faults(s)) and int(s.get('lastAlarm','0')) > last_audible,
                     'monitoring start sounds for an already active red fault, including at 2-minute polling')
            # Statistical axle alerts: real polling, per-sensor daily suppression and new large error.
            metadata_before_axles = metadata()
            stop_service()
            state_root = ET.fromstring(preferences_xml())
            for node in state_root:
                if node.get('name') in ('sound','running'): node.set('value','true')
                if node.get('name') == 'interval': node.set('value','30')
            (folder/'axle-start.xml').write_bytes(ET.tostring(state_root,encoding='utf-8'))
            install(folder/'axle-start.xml','shared_prefs/monitor.xml')
            phase.update(axles=5, axle_at=int(time.time())-20, bell_recovered=True)
            adb('shell','am','start','-n',PKG+'/.MainActivity')
            five = wait_for(lambda s: not faults(s) and int(s.get('lastSuccess','0')) > int(metadata_before_axles.get('lastSuccess','0')),
                            'five qualifying axle errors remain notes without alert')
            phase['axles'] = 6
            sixth = wait_for(lambda s: any(row[0].startswith('axle:3:') and 'thiếu 3 trục' in row[3] for row in faults(s))
                            and int(s.get('lastAlarm','0')) > int(five.get('lastAlarm','0')),
                            'sixth error for CB3 raises red warning with audible playback')
            seventh_at = int(sixth['lastSuccess'])
            sixth_alarm = int(sixth['lastAlarm'])
            phase['axles'] = 7
            seventh = wait_for(lambda s: int(s.get('lastSuccess','0')) > seventh_at,
                               'seventh measurement processed')
            assert int(seventh['lastAlarm']) == sixth_alarm, 'Seventh daily error must not replay warning'
            print('PASS: same sensor daily warning does not repeat after further errors',flush=True)
            stop_service()
            state_root = ET.fromstring(preferences_xml())
            for node in state_root:
                if node.get('name') == 'running': node.set('value','true')
            (folder/'axle-restart.xml').write_bytes(ET.tostring(state_root,encoding='utf-8'))
            install(folder/'axle-restart.xml','shared_prefs/monitor.xml')
            adb('shell','am','start','-n',PKG+'/.MainActivity')
            restarted = wait_for(lambda s: int(s.get('lastSuccess','0')) > int(seventh['lastSuccess']),
                                 'monitoring restart reuses axle notice ledger')
            assert int(restarted['lastAlarm']) == sixth_alarm, 'Restart must not replay already notified daily axle warning'
            print('PASS: restart does not replay daily axle warning',flush=True)
            phase['axle_other'] = True
            other = wait_for(lambda s: any(row[0].startswith('axle:4:') for row in faults(s))
                            and int(s.get('lastAlarm','0')) > sixth_alarm,
                            'another sensor reaching six errors creates a new audible alert')
            phase['axle_large'] = True
            large = wait_for(lambda s: any(row[0].startswith('axle:3:') and 'thiếu 12 trục trong 1 lần' in row[3] for row in faults(s))
                     and int(s.get('lastAlarm','0')) > int(other['lastAlarm']),
                     'new deviation above ten axles alerts even on previously notified sensor')
            phase['axle_exact'] = True
            wait_for(lambda s: any(row[0].startswith('axle:3:') and 'thiếu 10 trục trong 1 lần' in row[3] for row in faults(s))
                     and int(s.get('lastAlarm','0')) > int(large['lastAlarm']),
                     'exactly ten missing axles create another audible alert on previously warned sensor')
            run_diagram_checks()
            print('29 monitoring checks passed', flush=True)
        finally:
            stop_service();adb('shell','am','force-stop',PKG)
            install(folder/'original.xml','shared_prefs/monitor.xml')
            if original_db.returncode==0:install(folder/'original.db','databases/events.db')
            else:adb('shell','run-as',PKG,'rm','-f','databases/events.db')
            adb('shell','settings','put','global','http_proxy',old_proxy if old_proxy not in ('null','') else ':0')
            server.shutdown();server.server_close()
            adb('shell','am','start','-n',PKG+'/.MainActivity')

if __name__ == '__main__':
    main()
