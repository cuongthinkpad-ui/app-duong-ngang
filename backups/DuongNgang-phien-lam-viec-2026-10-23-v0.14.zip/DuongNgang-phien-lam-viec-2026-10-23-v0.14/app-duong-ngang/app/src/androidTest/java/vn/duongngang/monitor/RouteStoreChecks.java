package vn.duongngang.monitor;

import android.app.Instrumentation;
import android.content.Context;
import android.os.Bundle;
import java.util.List;

/** No test dependencies. Uses a separate device-protected sandbox, never the app's normal data. */
public final class RouteStoreChecks extends Instrumentation {
  private int checks;
  private boolean uiMode, previewMode, timingMode, telemetryMode;

  private void check(boolean result, String message) {
    checks++;
    if (!result) throw new AssertionError(message);
  }

  @Override
  public void onCreate(Bundle arguments) {
    super.onCreate(arguments);
    previewMode = arguments != null && "preview".equals(arguments.getString("mode"));
    uiMode = arguments != null && "ui".equals(arguments.getString("mode"));
    timingMode = arguments != null && "timing".equals(arguments.getString("mode"));
    telemetryMode = arguments != null && "telemetry".equals(arguments.getString("mode"));
    start();
  }

  @Override
  public void onStart() {
    if (telemetryMode) {
      Bundle result = new Bundle();
      try {
        result.putString(
            "stream", new TelemetryUiChecks(this).run() + " telemetry UI checks passed\n");
        finish(-1, result);
      } catch (Throwable failure) {
        result.putString("stream", "FAILED: " + failure + "\n");
        finish(0, result);
      }
      return;
    }
    if (timingMode) {
      Bundle result = new Bundle();
      try {
        result.putString("stream", TabSwitchChecks.run(this));
        finish(-1, result);
      } catch (Throwable failure) {
        result.putString("stream", "FAILED: " + failure + "\n");
        finish(0, result);
      }
      return;
    }
    if (previewMode) {
      Bundle result = new Bundle();
      try {
        UiPreview.capture(this);
        result.putString("stream", "Synthetic UI previews captured\n");
        finish(-1, result);
      } catch (Throwable failure) {
        result.putString("stream", "FAILED: " + failure + "\n");
        finish(0, result);
      }
      return;
    }
    if (uiMode) {
      Bundle result = new Bundle();
      try {
        result.putString("stream", new UiRefreshChecks(this).run() + " UI refresh checks passed\n");
        finish(-1, result);
      } catch (Throwable error) {
        result.putString("stream", "FAILED: " + error + "\n");
        finish(0, result);
      }
      return;
    }
    Context context = getTargetContext().createDeviceProtectedStorageContext();
    Store store = new Store(context);
    Bundle result = new Bundle();
    int code = -1;
    store.prefs.edit().clear().commit();
    context.deleteDatabase("events.db");
    try {
      store.credentials("https://rail.example.test/", "account-a", "test-only");
      String a = store.account();
      var routeA = new Rules.Route(List.of("275+290", "276+351", "279+000 (CS)"));
      var eventA = new Rules.Event("a", 1000, "Km 275+290", "Tàu lẻ", false, List.of());
      store.saveForAccount(a, new WebSource.DayData(List.of(eventA), routeA));
      check(store.route().points().equals(routeA.points()), "persist account inventory");
      check(store.events(0, 2000).size() == 1, "persist account events");
      store.prefs.edit().putString("rangeFrom", "276+351").putString("rangeTo", "276+351").commit();
      check(store.rangeFrom(routeA, false).equals("276+351"), "saved account range");
      store
          .prefs
          .edit()
          .putString(Store.rangeKey(true, true), "312+111")
          .putString(Store.rangeKey(true, false), "313+800")
          .commit();
      check(
          store.rangeFrom(routeA, false).equals("276+351"), "demo scope cannot change live scope");
      store.credentials("https://rail.example.test/", "account-b", "test-only");
      check(store.route().points().isEmpty(), "new ID starts without old route");
      check(store.events(0, 2000).isEmpty(), "new ID starts without old events");
      check(
          !store.prefs.contains("rangeFrom") && !store.prefs.contains("rangeTo"),
          "clear old account scope");
      boolean rejected = false;
      try {
        store.saveForAccount(a, new WebSource.DayData(List.of(eventA), routeA));
      } catch (IllegalStateException expected) {
        rejected = true;
      }
      check(
          rejected && store.route().points().isEmpty(),
          "late old-account request cannot publish route");
      var routeB = new Rules.Route(List.of("500+000", "501+100 (AB)", "502+200"));
      var eventB = new Rules.Event("b", 1000, "Km 502+200", "Tàu chẵn", false, List.of());
      store.saveForAccount(store.account(), new WebSource.DayData(List.of(eventB), routeB));
      check(
          store.rangeFrom(routeB, false).equals("500+000")
              && store.rangeTo(routeB, false).equals("502+200"),
          "new account defaults to its full route");
      check(store.events(0, 2000).get(0).id().equals("b"), "only current account records remain");
      store.credentials("https://rail.example.test/", "account-b", "test-only");
      check(store.route().points().equals(routeB.points()), "same ID retains route");
      var inferred = new Rules.Event("self:b", 1000, "Km 502+200", "Nghi tự kích", true, List.of());
      store.saveForAccount(store.account(), new WebSource.DayData(List.of(inferred), routeB));
      boolean originalProtected = false;
      try {
        store.discardInferences(store.account(), List.of("b"));
      } catch (IllegalArgumentException expected) {
        originalProtected = true;
      }
      check(
          originalProtected && store.events(0, 2000).size() == 2,
          "cannot delete a web record when removing a disproved inference");
      store.discardInferences(store.account(), List.of("self:b"));
      check(
          store.events(0, 2000).size() == 1,
          "disproved inference removed without altering original report");
      var oldBell =
          new Rules.Event("old-bell", 100, "Km 500+000", "Chuông 1 hỏng", true, List.of());
      store.saveForAccount(store.account(), new WebSource.DayData(List.of(oldBell), routeB));
      store.updateActiveFaults(store.account(), 0, 1000, 0, List.of());
      check(store.activeFaults().size() == 1, "active fault cache built");
      store.updateActiveFaults(store.account(), 1001, 2000, 0, List.of());
      check(store.activeFaults().size() == 1, "old unresolved fault survives later empty windows");
      var restoredBell =
          new Rules.Event(
              "restore-bell", 2500, "Km 500+000", "Chuông 1 khôi phục tốt", false, List.of());
      store.saveForAccount(store.account(), new WebSource.DayData(List.of(restoredBell), routeB));
      store.updateActiveFaults(store.account(), 2000, 3000, 0, List.of());
      check(store.activeFaults().isEmpty(), "later matching recovery clears carried fault");
      check(store.occupationEvents().size() == 1, "occupation survives empty later windows");
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "release", 3500, "Km 502+200", "Khôi phục hệ thống", false, List.of())),
              routeB));
      store.updateActiveFaults(store.account(), 3000, 4000, 0, List.of());
      check(store.occupationEvents().isEmpty(), "system recovery releases carried occupation");
      check(
          Rules.incidentHistory(store.incidentEvents(0, 1000)).stream()
              .anyMatch(i -> i.fault().id().equals("old-bell") && i.recovery() != null),
          "historical day links later recovery without reading all later train logs");
      store
          .prefs
          .edit()
          .putLong("lastFull", 3000)
          .putString("pendingSelf", "{\"case\":500}")
          .commit();
      check(
          store.pendingSelf().get("case") == 500L,
          "pending confirmation timestamps survive restart");
      long midnight = java.time.Instant.parse("2026-10-22T17:00:00Z").toEpochMilli();
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "yesterday-bell",
                      midnight - 1000,
                      "Km 500+000",
                      "Chuông 2 hỏng",
                      true,
                      List.of()),
                  new Rules.Event(
                      "new-day-lamp", midnight + 1000, "Km 500+000", "Đèn 1 hỏng", true, List.of()),
                  new Rules.Event(
                      "overnight-train",
                      midnight - 2000,
                      "Km 502+200",
                      "Tàu lẻ",
                      false,
                      List.of())),
              routeB));
      store.updateActiveFaults(store.account(), midnight - 3000, midnight - 1, 0, List.of());
      store.resetDailyFaults(midnight + 2000);
      check(
          store.activeFaults().size() == 1
              && store.activeFaults().get(0).id().equals("new-day-lamp"),
          "daily reset removes yesterday fault and retains new-day fault");
      check(
          store.occupationEvents().size() == 1
              && store.events(midnight - 3000, midnight).size() == 2,
          "daily reset retains overnight train and yesterday archive");
      check(
          store.pendingSelf().isEmpty() && store.prefs.getLong("baselineFrom", 0) == midnight,
          "daily reset clears pending inference and sets midnight boundary");
      store.prefs.edit().putString("pendingSelf", "{\"new-case\":500}").commit();
      store.resetDailyFaults(midnight + 3000);
      check(
          store.pendingSelf().containsKey("new-case"),
          "same-day reset is idempotent and retains new pending inference");
      var bridgeRoute = new Rules.Route(List.of("500+000", "501+500", "502+200"));
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "bridge-arrive", midnight + 10000, "500+000", "Tàu lẻ", false, List.of()),
                  new Rules.Event(
                      "bridge-pass",
                      midnight + 11000,
                      "500+000",
                      "Tàu lẻ đã qua đường ngang",
                      false,
                      List.of()),
                  new Rules.Event(
                      "bridge-restore",
                      midnight + 12000,
                      "500+000",
                      "Khôi phục hệ thống",
                      false,
                      List.of())),
              bridgeRoute));
      store.updateActiveFaults(store.account(), midnight, midnight + 20000, midnight, List.of());
      check(
          Rules.betweenCrossings(store.travelState()).size() == 1,
          "travel cache survives source restoration");
      long later = midnight + 3 * 86400000L + 20000;
      store.updateActiveFaults(store.account(), later, later, later - 20000, List.of());
      check(
          Rules.betweenCrossings(new Store(context).travelState()).size() == 1,
          "checkpoint preserves travel beyond two-day replay and across Store restart");
      store.resetDailyFaults(later);
      check(
          Rules.betweenCrossings(store.travelState()).size() == 1,
          "fault midnight reset does not erase between-crossing travel");
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "bridge-late-destination",
                      midnight + 2 * 86400000L + 5000,
                      "501+500",
                      "Tàu lẻ",
                      false,
                      List.of())),
              bridgeRoute));
      store.updateActiveFaults(store.account(), later, later, later - 20000, List.of());
      check(
          Rules.betweenCrossings(store.travelState()).isEmpty(),
          "late downstream backfill consumes the checkpointed leg");
      check(
          store.travelState().journeys().stream()
              .anyMatch(
                  j ->
                      "bridge-arrive".equals(j.id())
                          && "bridge-late-destination".equals(j.successorId())),
          "successor links persist across JSON and checkpoint replay");
      // Complete the unrelated overnight fixture before the isolated migration scenario.
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "migration-old-exit",
                      midnight - 1000,
                      "502+200",
                      "Khôi phục hệ thống",
                      false,
                      List.of())),
              bridgeRoute));
      int preservedEvents = store.events(0, later + 1).size();
      String preservedFaults = store.prefs.getString("activeFaults", "[]");
      store
          .prefs
          .edit()
          .remove("travelVersion")
          .putString("travelState", "[[\"old-ghost\",1,\"500+000\",\"501+500\",1,true,true,false]]")
          .putString(
              "travelCheckpoint", "[[\"old-ghost\",1,\"500+000\",\"501+500\",1,true,true,false]]")
          .commit();
      check(
          !store.travelReady() && store.travelState().journeys().isEmpty(),
          "obsolete diagram cache is not shown as current while migrating");
      store.prepareTravelState(store.account(), later);
      check(
          store.travelReady()
              && Rules.trackSegments(bridgeRoute, store.travelState())
                  .equals(List.of(new Rules.TrackSegment("500+000", "501+500", 1)))
              && store.events(0, later + 1).size() == preservedEvents
              && store.prefs.getString("activeFaults", "[]").equals(preservedFaults),
          "migration reconstructs from reports, removes old ghosts, and preserves raw/fault data");
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "migration-pass",
                      later - 500,
                      "501+500",
                      "Tàu lẻ đã qua đường ngang",
                      false,
                      List.of())),
              bridgeRoute));
      store.updateActiveFaults(store.account(), later - 500, later, later - 20000, List.of());
      check(
          Rules.trackSegments(bridgeRoute, store.travelState())
              .equals(List.of(new Rules.TrackSegment("501+500", "502+200", 1))),
          "passage immediately switches a checkpointed interval after migration");
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "migration-reverse", later - 400, "502+200", "Tàu chẵn", false, List.of())),
              bridgeRoute));
      store.updateActiveFaults(store.account(), later - 500, later, later - 20000, List.of());
      check(
          Rules.trackSegments(bridgeRoute, new Store(context).travelState())
              .equals(List.of(new Rules.TrackSegment(null, "502+200", -1))),
          "opposite evidence removes stale cached direction across Store restart");
      store.credentials("https://other.example.test/", "account-b", "test-only");
      check(
          store.route().points().isEmpty() && store.events(0, 2000).isEmpty(),
          "new URL isolates same ID");
      check(
          !store.prefs.contains("travelState")
              && !store.prefs.contains("travelVersion")
              && !store.prefs.contains("travelCheckpoint")
              && !store.prefs.contains("faultDay")
              && !store.prefs.contains("activeFaults")
              && !store.prefs.contains("occupiedPoints")
              && !store.prefs.contains("pendingSelf")
              && !store.prefs.contains("lastFull"),
          "new account clears inferred and active state");
      var manualRoute = new Rules.Route(List.of("100+000", "101+000", "102+000", "103+000"));
      long selfAt = midnight - 2 * 86400000L + 1000;
      long resetAt = midnight + 1000;
      var selfStart =
          new Rules.Event("manual-start", selfAt, "101+000", "Tàu lẻ", false, List.of());
      var selfFault =
          new Rules.Event("self:manual-start", selfAt, "101+000", "Nghi tự kích", true, List.of());
      var rawFault =
          new Rules.Event(
              "manual-bell", resetAt - 200, "101+000", "Chuông 2 hỏng", true, List.of());
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(List.of(selfStart, selfFault, rawFault), manualRoute));
      store.updateActiveFaults(store.account(), 0, resetAt - 100, 0, List.of());
      check(
          new Store(context).travelState().journeys().stream().anyMatch(j -> j.selfTriggered()),
          "self-trigger qualification persists across JSON and an old checkpoint");
      var resetEvent =
          new Rules.Event(
              "manual-reset", resetAt, "101+000", "  ấn  nút PHỤC HỒI ", false, List.of());
      store.saveForAccount(
          store.account(), new WebSource.DayData(List.of(resetEvent), manualRoute));
      store.updateActiveFaults(store.account(), resetAt + 1, resetAt + 500, 0, List.of());
      check(
          store.activeFaults().equals(List.of(rawFault))
              && Rules.trackSegments(manualRoute, store.travelState()).isEmpty(),
          "manual reset clears cached self fault and checkpointed diagram even before newest"
              + " delta");
      check(
          Rules.incidentHistory(store.incidentEvents(selfAt, selfAt + 60000)).stream()
              .anyMatch(i -> i.fault().equals(selfFault) && resetEvent.equals(i.recovery())),
          "historical self incident finds later manual recovery with original spelling");
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "manual-late",
                      resetAt + 1000,
                      "101+000",
                      "Tàu lẻ đã qua đường ngang",
                      false,
                      List.of())),
              manualRoute));
      store.updateActiveFaults(store.account(), resetAt + 501, resetAt + 1500, 0, List.of());
      check(
          Rules.trackSegments(manualRoute, new Store(context).travelState()).isEmpty(),
          "restart and late passage do not recreate manually reset train");
      store.prefs.edit().putInt("travelVersion", 2).commit();
      store.prepareTravelState(store.account(), resetAt + 1500);
      check(
          store.travelReady()
              && Rules.trackSegments(manualRoute, store.travelState()).isEmpty()
              && store.activeFaults().equals(List.of(rawFault)),
          "v0.10 cache migration replays manual reset without deleting device faults");
      store.credentials("https://rail.example.test/", "axle-account", "test-only");
      long axleDay = Rules.faultBaseline(0, System.currentTimeMillis());
      List<Rules.Event> measurements = new java.util.ArrayList<>();
      for (int i = 0; i < 5; i++)
        measurements.add(
            new Rules.Event(
                "axle-source-" + i,
                axleDay + 1000 + i * 1000,
                "101+000",
                "Khôi phục hệ thống",
                false,
                List.of("40", "40", "37", "40", "40", "40")));
      store.saveForAccount(store.account(), new WebSource.DayData(measurements, manualRoute));
      store.updateActiveFaults(store.account(), axleDay, axleDay + 6000, axleDay, List.of());
      check(
          store.activeFaults().isEmpty(), "five saved axle deviations do not become active alerts");
      var sixthAxle =
          new Rules.Event(
              "axle-source-sixth",
              axleDay + 7000,
              "101+000",
              "Khôi phục hệ thống",
              false,
              List.of("40", "40", "37", "40", "40", "40"));
      store.saveForAccount(store.account(), new WebSource.DayData(List.of(sixthAxle), manualRoute));
      store.updateActiveFaults(
          store.account(), axleDay + 7000, axleDay + 8000, axleDay + 7500, List.of());
      check(
          store.activeFaults().size() == 1
              && Rules.isAxleFault(store.activeFaults().get(0))
              && store.activeFaults().get(0).text().contains("thiếu 3 trục"),
          "sixth deviation raises an alert despite later generic fault baseline");
      check(
          store.events(axleDay, axleDay + 8000).stream().filter(e -> !Rules.isGenerated(e)).count()
              == 6,
          "derived axle alert preserves all original measurements");
      String axleId = store.activeFaults().get(0).id();
      var firstAxleNotice = store.activeFaults().get(0);
      check(
          store.claimAxleNotice(firstAxleNotice, axleDay + 8000)
              && !new Store(context).claimAxleNotice(firstAxleNotice, axleDay + 8001),
          "daily axle warning notifies once even after Store restart");
      store.updateActiveFaults(store.account(), axleDay + 8001, axleDay + 9000, axleDay, List.of());
      check(
          store.activeFaults().size() == 1
              && new Store(context).activeFaults().get(0).id().equals(axleId)
              && store.events(axleDay, axleDay + 9000).size() == 7,
          "poll and Store restart retain one stable alert without counting it again");
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "axle-correct",
                      axleDay + 10000,
                      "101+000",
                      "Khôi phục hệ thống",
                      false,
                      List.of("40", "40", "40", "40", "40", "40"))),
              manualRoute));
      store.updateActiveFaults(
          store.account(), axleDay + 10000, axleDay + 11000, axleDay, List.of());
      check(
          store.activeFaults().size() == 1,
          "a later correct count keeps the statistical alert for the day");
      store.resetDailyFaults(axleDay + 86400000 + 1000);
      check(store.activeFaults().isEmpty(), "midnight resets current axle warnings");
      check(
          Rules.incidentHistory(store.incidentEvents(axleDay, axleDay + 86400000)).stream()
              .anyMatch(i -> Rules.isAxleFault(i.fault())),
          "daily reset preserves historical axle warning");
      store.saveForAccount(
          store.account(),
          new WebSource.DayData(
              List.of(
                  new Rules.Event(
                      "axle-backfill",
                      axleDay + 500,
                      "101+000",
                      "Khôi phục hệ thống",
                      false,
                      List.of("40", "40", "37", "40", "40", "40"))),
              manualRoute));
      store.syncAxleAlerts(store.account(), axleDay, axleDay + 86400000);
      var backfilled =
          store.events(axleDay, axleDay + 86400000).stream()
              .filter(Rules::isAxleFault)
              .collect(java.util.stream.Collectors.toList());
      check(
          backfilled.size() == 1
              && !backfilled.get(0).id().equals(axleId)
              && backfilled.get(0).at() == axleDay + 5000,
          "late earlier measurement moves sixth threshold and removes obsolete generated alert");
      check(
          !store.claimAxleNotice(backfilled.get(0), axleDay + 30000),
          "moving sixth measurement after backfill never notifies the same sensor again");
      var bigSame =
          new Rules.Event(
              "axle:3:large-test",
              axleDay + 20000,
              "101+000",
              "CB3 đếm thiếu 12 trục trong 1 lần · Sai 7 lần trong ngày",
              true,
              List.of("40", "40", "28", "40", "40", "40"));
      check(
          store.claimAxleNotice(bigSame, axleDay + 30000)
              && !store.claimAxleNotice(bigSame, axleDay + 30001),
          "new single deviation above ten notifies same sensor once per measurement");
      var otherSensor =
          new Rules.Event(
              "axle:4:other-sensor",
              axleDay + 20000,
              "101+000",
              "CB4 đếm sai 6 lần trong ngày",
              true,
              List.of("40", "40", "40", "37", "40", "40"));
      check(
          store.claimAxleNotice(otherSensor, axleDay + 30000),
          "another sensor has its own daily notification");
      check(
          !store.claimAxleNotice(firstAxleNotice, axleDay + 86400000 + 1000),
          "old day warnings do not ring on the next day");
      var newDayNotice =
          new Rules.Event(
              "axle:3:new-day",
              axleDay + 86400000 + 1000,
              "101+000",
              "CB3 đếm sai 6 lần trong ngày",
              true,
              List.of("40", "40", "37", "40", "40", "40"));
      check(
          store.claimAxleNotice(newDayNotice, axleDay + 86400000 + 2000),
          "same sensor can notify again only on a new day or a new large deviation");
      store.credentials("https://rail.example.test/", "exempt-upgrade", "test-only");
      var exemptSource = new java.util.ArrayList<Rules.Event>();
      for (int i = 0; i < 7; i++)
        exemptSource.add(
            new Rules.Event(
                "exempt-source-" + i,
                axleDay + 1000 + i * 1000,
                "Km 320+445",
                "Khôi phục hệ thống",
                false,
                List.of("40", "40", i == 6 ? "28" : "37", "40", "40", "40")));
      var legacyExempt =
          new Rules.Event(
              "axle:3:legacy-exempt",
              axleDay + 7000,
              "Km 320+445",
              "CB3 đếm thiếu 12 trục trong 1 lần",
              true,
              List.of("40", "40", "28", "40", "40", "40"));
      var legacyOldDay =
          new Rules.Event(
              "axle:3:legacy-exempt-yesterday",
              axleDay - 1000,
              "320+445",
              "CB3 đếm sai 6 lần trong ngày",
              true,
              List.of("40", "40", "37", "40", "40", "40"));
      var cacheOnlyExempt =
          new Rules.Event(
              "axle:4:legacy-cache-only",
              axleDay + 7000,
              "320+445",
              "CB4 đếm thiếu 12 trục trong 1 lần",
              true,
              List.of());
      var actualExempt =
          new Rules.Event(
              "actual-exempt-red", axleDay + 9000, "320+445", "Cảm biến 3 hỏng", true, List.of());
      var neighborSource =
          new Rules.Event(
              "normal-neighbor",
              axleDay + 9000,
              "320+957",
              "Khôi phục hệ thống",
              false,
              List.of("40", "40", "30", "40", "40", "40"));
      exemptSource.addAll(List.of(legacyExempt, legacyOldDay, actualExempt, neighborSource));
      store.saveForAccount(store.account(), new WebSource.DayData(exemptSource, Rules.DEMO_ROUTE));
      var oldCache = new org.json.JSONArray();
      for (var e : List.of(legacyExempt, cacheOnlyExempt, actualExempt))
        oldCache.put(
            new org.json.JSONArray()
                .put(e.id())
                .put(e.at())
                .put(e.crossing())
                .put(e.text())
                .put(new org.json.JSONArray(e.counts())));
      store
          .prefs
          .edit()
          .putString("activeFaults", oldCache.toString())
          .putInt("axleVersion", 1)
          .commit();
      check(
          store.activeFaults().equals(List.of(actualExempt)),
          "v0.12 cached 320+445 axle alert is hidden immediately without hiding its hardware"
              + " fault");
      check(
          !store.claimAxleNotice(legacyExempt, axleDay + 20000)
              && store.claimAxleNotice(actualExempt, axleDay + 20000),
          "excluded axle alert cannot notify but original red fault can");
      var manager = context.getSystemService(android.app.NotificationManager.class);
      manager.createNotificationChannel(
          new android.app.NotificationChannel(
              "exempt-upgrade-test",
              "Fixture only",
              android.app.NotificationManager.IMPORTANCE_LOW));
      int obsoleteNotification = 100 + Math.floorMod(legacyExempt.id().hashCode(), 1000000);
      manager.notify(
          obsoleteNotification,
          new android.app.Notification.Builder(context, "exempt-upgrade-test")
              .setSmallIcon(vn.duongngang.monitor.R.drawable.ic_train_header)
              .setContentTitle("Synthetic upgrade check")
              .build());
      int cacheOnlyNotification = 100 + Math.floorMod(cacheOnlyExempt.id().hashCode(), 1000000);
      manager.notify(
          cacheOnlyNotification,
          new android.app.Notification.Builder(context, "exempt-upgrade-test")
              .setSmallIcon(vn.duongngang.monitor.R.drawable.ic_train_header)
              .setContentTitle("Synthetic cache-only check")
              .build());
      store.updateActiveFaults(store.account(), axleDay, axleDay + 20000, axleDay, List.of());
      check(
          store.axleReady()
              && store.activeFaults().size() == 2
              && store.activeFaults().stream().anyMatch(e -> e.id().equals(actualExempt.id()))
              && store.activeFaults().stream()
                  .anyMatch(e -> Rules.isAxleFault(e) && e.crossing().equals("320+957")),
          "upgrade keeps hardware and normal-crossing axle warnings while exempting 320+445");
      check(
          java.util.Arrays.stream(manager.getActiveNotifications())
              .noneMatch(
                  n -> n.getId() == obsoleteNotification || n.getId() == cacheOnlyNotification),
          "upgrade cancels obsolete axle notifications including a cache-only alert");
      manager.deleteNotificationChannel("exempt-upgrade-test");
      try (var db = context.openOrCreateDatabase("events.db", 0, null);
          var c =
              db.rawQuery(
                  "SELECT COUNT(*) FROM events WHERE id IN (?,?)",
                  new String[] {legacyExempt.id(), legacyOldDay.id()})) {
        c.moveToFirst();
        check(c.getInt(0) == 0, "upgrade deletes derived exempt alerts from every stored day");
      }
      check(
          store.events(axleDay, axleDay + 20000).stream()
                  .filter(e -> e.id().startsWith("exempt-source-"))
                  .count()
              == 7,
          "upgrade preserves all original 320+445 measurements");
      check(
          Rules.incidentHistory(store.incidentEvents(axleDay - 86400000, axleDay)).isEmpty(),
          "historical incident screen does not recreate exempt axle warnings");
      store.credentials("https://rail.example.test/", "new-axle-account", "test-only");
      check(
          store.activeFaults().isEmpty()
              && !store.prefs.contains("axleVersion")
              && !store.prefs.contains("axleNotices")
              && store.events(axleDay, axleDay + 86400000).isEmpty(),
          "changing account clears axle counters and generated alerts");
      result.putString("stream", checks + " account storage checks passed\n");

    } catch (Throwable failure) {
      result.putString("stream", "FAILED: " + failure + "\n");
      code = 0;
    } finally {
      store.prefs.edit().clear().commit();
      context.deleteDatabase("events.db");
    }
    finish(code, result);
  }
}
