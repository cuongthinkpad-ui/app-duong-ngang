package vn.duongngang.monitor;

import android.app.*;
import android.content.*;
import android.os.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.JSONObject;

public class MonitorService extends Service {
  public static final String UPDATE = "vn.duongngang.monitor.UPDATE";
  private ScheduledExecutorService worker;
  private final Object pollLock = new Object();
  private ScheduledFuture<?> nextPoll;
  private boolean polling, retryRequested;
  private long pollGeneration;
  private static final long RECONNECT_SECONDS = 120;
  private PowerManager.WakeLock wake;
  private Store store;
  private final AlarmSound alarm = new AlarmSound();
  private VoiceAlarm voice;
  private final Set<String> ringingFaults = ConcurrentHashMap.newKeySet();
  private final Handler dailyHandler = new Handler(Looper.getMainLooper());
  private final Runnable dailyReset =
      () -> {
        resetDailyFaults();
        scheduleDailyReset();
      };

  private void resetDailyFaults() {
    store.resetDailyFaults(System.currentTimeMillis());
    Set<Integer> open = new HashSet<>();
    for (var fault : store.activeFaults()) open.add(notificationId(fault));
    var manager = getSystemService(NotificationManager.class);
    for (var notification : manager.getActiveNotifications())
      if (notification.getId() != 1 && !open.contains(notification.getId()))
        manager.cancel(notification.getId());
    Set<String> current = new HashSet<>();
    for (var fault : store.activeFaults()) current.add(fault.id());
    ringingFaults.retainAll(current);
    if (voice != null) voice.retain(current);
    if (ringingFaults.isEmpty()) stopAlerts();
    sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
  }

  private void scheduleDailyReset() {
    dailyHandler.removeCallbacks(dailyReset);
    long midnight =
        LocalDate.now(WebSource.ZONE)
            .plusDays(1)
            .atStartOfDay(WebSource.ZONE)
            .toInstant()
            .toEpochMilli();
    dailyHandler.postDelayed(dailyReset, Math.max(1, midnight - System.currentTimeMillis()));
  }

  @Override
  public void onCreate() {
    super.onCreate();
    store = new Store(this);
    store.prefs.edit().putBoolean("connectionRetrying", false).putBoolean("dataLoading", false).apply();
    voice = new VoiceAlarm(this, message -> store.prefs.edit().putString("voiceStatus", message).apply());
    store.prefs.edit().putString("voiceStatus", AlertOptions.SILENT.equals(store.alertMode())
        ? "Đã tắt âm thanh cảnh báo" : AlertOptions.BELL.equals(store.alertMode())
            ? "Chế độ chỉ chuông" : "Giọng đọc sử dụng tiếng Việt của điện thoại").apply();
    var manager = getSystemService(NotificationManager.class);
    manager.createNotificationChannel(
        new NotificationChannel("monitor", "Theo dõi nền", NotificationManager.IMPORTANCE_LOW));
    var alerts = new NotificationChannel("faults_alerts_027", "Thông báo sự cố", NotificationManager.IMPORTANCE_HIGH);
    alerts.setSound(null, null);
    alerts.enableVibration(false);
    manager.createNotificationChannel(alerts);
    var silent =
        new NotificationChannel(
            "faults_silent", "Sự cố im lặng", NotificationManager.IMPORTANCE_HIGH);
    silent.setSound(null, null);
    silent.enableVibration(false);
    manager.createNotificationChannel(silent);
  }

  private void stopAlerts() {
    alarm.stop();
    if (voice != null) voice.stop();
  }

  private void playAlerts(String account, List<Rules.Event> events, long now) {
    String mode = store.alertMode();
    if (AlertOptions.SILENT.equals(mode)) { stopAlerts(); return; }
    if (AlertOptions.BELL.equals(mode)) {
      voice.stop();
      if (alarm.play(this)) store.prefs.edit().putLong("lastAlarm", now).apply();
    } else {
      alarm.stop();
      voice.enqueue(events,
          () -> store.account().equals(account) && AlertOptions.VOICE.equals(store.alertMode())
              && !store.historicalMonitoring() && store.prefs.getBoolean("running", false)
              && events.stream().anyMatch(e -> ringingFaults.contains(e.id())
                  && e.at() >= Rules.faultBaseline(store.prefs.getLong("baselineFrom", 0), System.currentTimeMillis())),
          () -> store.prefs.edit().putLong("lastAlarm", System.currentTimeMillis()).apply());
    }
  }

  private PendingIntent open() {
    return PendingIntent.getActivity(
        this,
        0,
        new Intent(this, MainActivity.class),
        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
  }

  private Notification.Action stopAlertAction() {
    // Deliver directly to the service: no Activity or persistent mute setting is needed.
    var pending = PendingIntent.getService(this, 1,
        new Intent(this, MonitorService.class).setAction("MUTE_ALARM"),
        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    return new Notification.Action.Builder(android.R.drawable.ic_media_pause,
        "XÁC NHẬN", pending).build();
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int id) {
    if (intent != null && "RETRY_CONNECTION".equals(intent.getAction())) {
      synchronized (pollLock) {
        if (worker != null) {
          if (polling) retryRequested = true;
          else schedulePoll(worker, 0);
          return START_STICKY;
        }
      }
      if (!store.prefs.getBoolean("running", false)) {
        stopSelf();
        return START_NOT_STICKY;
      }
    }
    if (intent != null && "MUTE_ALARM".equals(intent.getAction())) {
      // Serialize with poll's alert dispatch. A queued TTS introduction also checks
      // ringingFaults before starting, so late callbacks cannot revive this batch.
      synchronized (Store.class) {
        ringingFaults.clear();
        stopAlerts();
      }
      if (worker == null) stopSelf();
      return worker == null ? START_NOT_STICKY : START_STICKY;
    }
    if ((intent == null && !store.prefs.getBoolean("running", false))
        || (intent != null && "STOP".equals(intent.getAction()))) {
      stopSelf();
      return START_NOT_STICKY;
    }
    if (intent != null && "RESTART".equals(intent.getAction())) stopAlerts();
    if (intent != null && "RESTART".equals(intent.getAction()) && worker != null) {
      synchronized (pollLock) {
        worker.shutdownNow();
        worker = null;
        polling = retryRequested = false;
      }
      source = null;
      firstPoll = true;
    }
    var notification =
        new Notification.Builder(this, "monitor")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Đang theo dõi đường ngang")
            .setContentText("Chạm để xem tình trạng cập nhật")
            .setContentIntent(open())
            .setOngoing(true)
            .addAction(stopAlertAction())
            .build();
    startForeground(1, notification);
    if (worker == null) {
      wake =
          ((PowerManager) getSystemService(POWER_SERVICE))
              .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DuongNgang:Monitoring");
      wake.setReferenceCounted(false);
      wake.acquire(600000L);
      worker = Executors.newSingleThreadScheduledExecutor();
      schedulePoll(worker, 0);
    }
    store.prefs.edit().putBoolean("running", true).apply();
    resetDailyFaults();
    scheduleDailyReset();
    return START_STICKY;
  }

  private WebSource source;
  private String sourceAccount = "";
  private boolean firstPoll = true;

  private void schedulePoll(ScheduledExecutorService executor, long seconds) {
    synchronized (pollLock) {
      if (worker != executor || executor.isShutdown()) return;
      if (nextPoll != null) nextPoll.cancel(false);
      long token = ++pollGeneration;
      nextPoll = executor.schedule(() -> runPoll(executor, token), seconds, TimeUnit.SECONDS);
    }
  }

  private void runPoll(ScheduledExecutorService executor, long token) {
    long started = SystemClock.elapsedRealtime();
    synchronized (pollLock) {
      if (worker != executor || token != pollGeneration) return;
      polling = true;
      store.prefs.edit().putLong("lastConnectionAttempt", System.currentTimeMillis())
          .putBoolean("dataLoading", true)
          .putBoolean("connectionRetrying", store.prefs.getBoolean("connectionLost", false)).apply();
    }
    sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
    try {
      poll();
    } finally {
      synchronized (pollLock) {
        if (worker == executor && !executor.isShutdown()) {
          polling = false;
          store.prefs.edit().putBoolean("connectionRetrying", false).putBoolean("dataLoading", false).apply();
          long delay = retryRequested ? 0
              : store.prefs.getBoolean("connectionLost", false) ? RECONNECT_SECONDS
                  : Math.max(0, Rules.POLL_SECONDS
                      - TimeUnit.MILLISECONDS.toSeconds(SystemClock.elapsedRealtime() - started));
          retryRequested = false;
          schedulePoll(executor, delay);
        }
      }
      sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
    }
  }

  private void poll() {
    String account = store.account();
    if (wake != null) wake.acquire(600000L);
    try {
      WebSource pollSource;
      synchronized (Store.class) {
        if (!store.account().equals(account) || Thread.currentThread().isInterrupted()) return;
        store.maintainHistory(account, System.currentTimeMillis());
        if (source == null || !sourceAccount.equals(account)) {
          source =
              new WebSource(
                  store.prefs.getString("url", ""),
                  store.prefs.getString("user", ""),
                  store.password());
          sourceAccount = account;
        }
        pollSource = source;
      }
      if (store.historicalMonitoring()) {
        LocalDate selected = store.monitoringDay();
        stopAlerts();
        ringingFaults.clear();
        // A completed past day needs no full two-day download on every 30-second tick.
        if (!store.prefs.getBoolean("connectionLost", false) && store.dayComplete(selected) && selected.toString().equals(store.prefs.getString("historyReadDay", ""))
            && System.currentTimeMillis() - store.prefs.getLong("historyReadAt", 0) < 15 * 60000L)
          return;
        var data = pollSource.readDay(selected);
        List<Rules.Event> historical = new ArrayList<>(data.events());
        if (!selected.minusDays(1).isBefore(LocalDate.now(WebSource.ZONE).minusDays(29)))
          historical.addAll(pollSource.readDay(selected.minusDays(1)).events());
        synchronized (Store.class) {
          if (!store.account().equals(account) || Thread.currentThread().isInterrupted()
              || !store.monitoringDay().equals(selected)) return;
          store.saveHistoricalDay(account, selected, new WebSource.DayData(historical, data.route()));
          store.prefs.edit().putString("historyReadDay", selected.toString())
              .putBoolean("connectionLost", false)
              .putLong("historyReadAt", System.currentTimeMillis())
              .putString("status", "Đã tải lịch sử · " + selected.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")))
              .apply();
        }
        sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
        return;
      }
      LocalDate today = LocalDate.now(WebSource.ZONE);
      long dayStart = today.atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli();
      long previousStart =
          today.minusDays(1).atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli();
      long last = store.prefs.getLong("lastSuccess", 0), started = System.currentTimeMillis();
      boolean reset = Rules.needsNewBaseline(last, started, firstPoll);
      boolean newDay =
          last > 0
              && Instant.ofEpochMilli(last).atZone(WebSource.ZONE).toLocalDate().isBefore(today);
      boolean history = last == 0 || reset || newDay || store.prefs.getLong("coverage", 0) == 0;
      boolean full = history || started - store.prefs.getLong("lastFull", 0) >= 15 * 60000L;
      List<Rules.Event> incoming = new ArrayList<>();
      if (history) {
        if (last == 0) {
          store
              .prefs
              .edit()
              .putString("status", "Đang đọc báo cáo ngày trước để nối trạng thái…")
              .apply();
          sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
        }
        incoming.addAll(pollSource.readDay(today.minusDays(1)).events());
      }
      Set<String> known = new HashSet<>();
      if (!full)
        for (var e : store.events(dayStart, started + 1))
          if (!Rules.isGenerated(e)) known.add(e.id());
      var data = full ? pollSource.readDay(today) : pollSource.readDelta(today, known);
      incoming.addAll(data.events());
      if (!data.connected()) reset = true;
      incoming.sort(Comparator.comparingLong(Rules.Event::at));
      synchronized (Store.class) {
        if (!store.account().equals(account) || Thread.currentThread().isInterrupted()) return;
        if (store.historicalMonitoring()) return;
        List<Rules.Event> added =
            new ArrayList<>(
                store.saveForAccount(account, new WebSource.DayData(incoming, data.route())));
        long now = System.currentTimeMillis();
        store.prepareSelfEvidence(account, now);
        long coverage = history ? previousStart : store.prefs.getLong("coverage", dayStart);
        if (history && !incoming.isEmpty()) coverage = Math.max(coverage, incoming.get(0).at());
        if (reset && !data.connected()) coverage = now;
        long selfFrom = last == 0 || reset ? now : store.prefs.getLong("selfFrom", now);
        if (reset) store.prefs.edit().putLong("baselineFrom", newDay ? dayStart : now).apply();
        List<Rules.Event> cached = store.events(Math.max(previousStart, coverage), now + 1);
        List<Rules.Event> original = new ArrayList<>();
        for (var event : cached) if (!Rules.isGenerated(event)) original.add(event);
        boolean detectSelf = Rules.selfTriggerEnabled(Rules.POLL_SECONDS);
        List<Rules.Event> candidates =
            detectSelf ? Rules.suspectedSelfTriggers(data.route(), original, coverage) : List.of();
        Set<String> candidateIds = new HashSet<>();
        for (var event : candidates) candidateIds.add(event.id());
        // Turning inference off must not erase the evidence that a manual reset ended
        // an already classified journey, or replay could display it as a real train again.
        Set<String> manuallyRestored = new HashSet<>();
        if (!detectSelf) {
          Map<String, Long> resets = new HashMap<>();
          for (var event : cached)
            if (!event.red() && Rules.isManualRecovery(event.text()))
              resets.merge(Rules.km(event.crossing()), event.at(), Math::max);
          for (var event : cached)
            if (Rules.isSelfTrigger(event)
                && resets.getOrDefault(Rules.km(event.crossing()), Long.MIN_VALUE) >= event.at())
              manuallyRestored.add(event.id());
        }
        List<String> disproved = new ArrayList<>();
        for (var event : cached)
          if (Rules.isSelfTrigger(event)
              && !candidateIds.contains(event.id().substring(5))
              && (detectSelf || event.at() >= dayStart && !manuallyRestored.contains(event.id())))
            disproved.add(event.id());
        store.discardInferences(account, disproved);
        Map<String, Long> pending =
            last == 0 || reset || !detectSelf ? new HashMap<>() : store.pendingSelf();
        Set<String> freshArrivals = new HashSet<>();
        for (var event : added)
          if (Rules.direction(event.text()) != 0) freshArrivals.add(event.id());
        List<Rules.Event> eligible = new ArrayList<>();
        if (detectSelf && last > 0 && !reset)
          for (var candidate : candidates)
            if (freshArrivals.contains(candidate.id()) || pending.containsKey(candidate.id()))
              eligible.add(candidate);
        var confirmed =
            Rules.confirmedSelfTriggers(
                eligible,
                pending,
                now,
                0,
                Math.max(30000L, 1000L * Rules.POLL_SECONDS));
        added.addAll(store.saveForAccount(account, new WebSource.DayData(confirmed, data.route())));
        long baseline = Rules.faultBaseline(store.prefs.getLong("baselineFrom", 0), now);
        long replayFrom = incoming.stream().mapToLong(Rules.Event::at).min().orElse(now);
        for (var event : confirmed) replayFrom = Math.min(replayFrom, event.at());
        Set<String> previousAxles = new HashSet<>();
        for (var event : store.activeFaults())
          if (Rules.isAxleFault(event)) previousAxles.add(event.id());
        var active = store.updateActiveFaults(account, replayFrom, now, baseline, disproved);
        for (var event : active)
          if (Rules.isAxleFault(event) && !previousAxles.contains(event.id())) added.add(event);
        Set<String> open = new HashSet<>();
        Set<Integer> notificationIds = new HashSet<>();
        for (var event : active) {
          open.add(event.id());
          if (data.route()
              .inRange(
                  event.crossing(),
                  store.rangeFrom(data.route(), false),
                  store.rangeTo(data.route(), false))) notificationIds.add(notificationId(event));
        }
        var manager = getSystemService(NotificationManager.class);
        for (var notification : manager.getActiveNotifications())
          if (notification.getId() != 1 && !notificationIds.contains(notification.getId()))
            manager.cancel(notification.getId());
        ringingFaults.retainAll(open);
        voice.retain(open);
        if (ringingFaults.isEmpty() || !store.prefs.getBoolean("sound", true)) stopAlerts();
        Map<String, Rules.Event> audibleNew = new LinkedHashMap<>();
        if (last > 0 && !reset)
          for (var event : added)
            if (event.red()
                && open.contains(event.id())
                && (detectSelf || !Rules.isSelfTrigger(event))
                && notificationIds.contains(notificationId(event))
                && store.claimAxleNotice(event, now)) {
              notifyFault(event);
              ringingFaults.add(event.id());
              audibleNew.put(event.id(), event);
            }
        // Reopening/recreating the service must not replay cached unresolved faults.
        // Only newly imported eligible faults above may start an audible batch.
        if (!audibleNew.isEmpty() && store.prefs.getBoolean("sound", true))
          playAlerts(account, new ArrayList<>(audibleNew.values()), now);
        firstPoll = false;
        var preferences =
            store
                .prefs
                .edit()
                .putBoolean("connectionLost", false)
                .putLong("lastSuccess", now)
                .putLong("coverage", coverage)
                .putLong("selfFrom", selfFrom)
                .putString("pendingSelf", new JSONObject(pending).toString())
                .putString(
                    "status",
                    reset ? "Đã đặt lại theo dõi · Chưa ghi nhận lỗi mới" : "Đã cập nhật");
        if (full) preferences.putLong("lastFull", now);
        preferences.apply();
      }
    } catch (Exception error) {
      if (!store.account().equals(account) || Thread.currentThread().isInterrupted()) return;
      store
          .prefs
          .edit()
          .putString(
              "status", error.getMessage() == null ? "Gián đoạn theo dõi" : error.getMessage())
          .apply();
      if (error instanceof java.io.IOException)
        store.prefs.edit().putBoolean("connectionLost", true).apply();
      if (error instanceof WebSource.AuthenticationException) stopSelf();
    }
    sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
  }

  private int notificationId(Rules.Event event) {
    return 100 + Math.floorMod(event.id().hashCode(), 1000000);
  }

  private void notifyFault(Rules.Event e) {
    boolean sound = store.prefs.getBoolean("sound", true);
    var n =
        new Notification.Builder(this, sound ? "faults_alerts_027" : "faults_silent")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(
                java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")
                        .withZone(WebSource.ZONE)
                        .format(Instant.ofEpochMilli(e.at()))
                    + " · "
                    + e.crossing())
            .setContentText(e.text())
            .setStyle(new Notification.BigTextStyle().bigText(e.text()))
            .setContentIntent(open())
            .addAction(stopAlertAction())
            .setAutoCancel(true)
            .build();
    getSystemService(NotificationManager.class).notify(notificationId(e), n);
  }

  @Override
  public void onDestroy() {
    dailyHandler.removeCallbacks(dailyReset);
    stopAlerts();
    if (voice != null) voice.close();
    ringingFaults.clear();
    synchronized (pollLock) {
      if (worker != null) worker.shutdownNow();
      worker = null;
      polling = retryRequested = false;
      store.prefs.edit().putBoolean("connectionRetrying", false).putBoolean("dataLoading", false).apply();
    }
    if (wake != null && wake.isHeld()) wake.release();
    store.prefs.edit().putBoolean("running", false).apply();
    sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
    super.onDestroy();
  }

  @Override
  public IBinder onBind(Intent intent) {
    return null;
  }
}
