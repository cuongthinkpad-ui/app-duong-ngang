package vn.duongngang.monitor;

import android.animation.ValueAnimator;
import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.concurrent.*;

/** Native Android presentation. Demo events never enter the operational store. */
public class MainActivity extends Activity {
  private static final int BLUE = 0xFF00D9EF,
      INK = 0xFFF1F6FF,
      MUTED = 0xFF94A3B8,
      BG = 0xFF060E1F,
      LINE = 0xFF25334D,
      GREEN = 0xFF35D6A0,
      RED = 0xFFFFA3AD,
      DANGER = 0xFFEF4444,
      SURFACE = 0xFF101C36,
      TINT = 0xFF122D42,
      FAULT = 0xFF26131F,
      FAULT_TINT = 0xFF55212F,
      GOOD = 0xFF0C292C,
      BUTTON_TEXT = 0xFF071724,
      WARNING = 0xFFFBBF24;
  private Store store;
  private LinearLayout screen, content;
  private TextView status, routeNote, summaryTitle, summaryDetail, summaryTime, voiceState;
  private LinearLayout summaryCard;
  private View summaryConfirm;
  private LinearLayout reconnectPanel;
  private View reconnectButton;
  private TextView connectionState, connectionWarning;
  private ProgressBar connectionProgress;
  private SummaryRing summaryRing;
  private ImageView headerMark;
  private TextView liveBadge;
  private View incidentTabIcon;
  private boolean navHasFault;
  private ValueAnimator lightPulse;
  private int lightLevel = -1;
  private boolean uiVisible, windowFocused;
  private LinearLayout routeWrapper;
  private RouteView routeView;
  private ScrollView pageScroll;
  private List<String> renderedRoute = List.of();
  private String page = "overview",
      filter = "Tất cả",
      selectedCrossing = "312+111",
      incidentFilter = "Tất cả";
  private boolean demo = false, expanded = false, followToday = true;
  private LocalDate selected = LocalDate.now(WebSource.ZONE);
  private LocalDate detailDay;
  private boolean detailFollowToday;
  private LocalDate historyDay = LocalDate.now(WebSource.ZONE);
  private boolean historyFollowToday = true, preparingLocalData;
  private final long demoClock = System.currentTimeMillis();
  private final ExecutorService io = Executors.newSingleThreadExecutor();
  private final ExecutorService dataIo = Executors.newSingleThreadExecutor();
  private record DayView(String revision, List<Rules.Event> events,
      List<Rules.Event> incidents, List<Rules.Event> travelEvents, Rules.TravelState travel) {}
  private final Map<String, DayView> dayViews = new HashMap<>();
  private final Set<String> pendingDays = new HashSet<>();
  private final Set<String> loadingDays = new HashSet<>();

  private String dayKey(LocalDate day) { return store.account() + "\n" + day; }
  private String dataRevision() {
    return store.prefs.getLong("dataRevision", 0) + ":" + store.prefs.getLong("lastSuccess", 0)
        + ":" + store.prefs.getLong("historyReadAt", 0) + ":" + store.monitoringDay()
        + ":" + Rules.POLL_SECONDS;
  }
  private boolean dayLoaded(LocalDate day) { return dayViews.containsKey(dayKey(day)); }

  /** Read SQLite, rebuild daily alerts and assemble history away from the UI thread. */
  private DayView dayData(LocalDate day) {
    String key = dayKey(day), revision = dataRevision(), account = store.account();
    DayView cached = dayViews.get(key);
    if ((cached == null || !cached.revision().equals(revision))
        && !dataIo.isShutdown() && pendingDays.add(key)) {
      dataIo.execute(() -> {
        DayView loaded = null;
        try {
          synchronized (Store.class) {
            if (!store.account().equals(account)) return;
            long from = day.atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli();
            long to = day.plusDays(1).atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli();
            if (day.equals(LocalDate.now(WebSource.ZONE))) to = System.currentTimeMillis() + 1;
            var events = Rules.dailyRecords(store.route(), store.events(from, to));
            var incidents = day.equals(LocalDate.now(WebSource.ZONE))
                ? store.incidentEvents(from, to) : events;
            var travel = day.equals(store.monitoringDay()) && store.historicalMonitoring()
                ? store.events(Rules.historyCutoff(System.currentTimeMillis()), to) : List.<Rules.Event>of();
            var state = Rules.diagramEnabled(Rules.POLL_SECONDS)
                ? Rules.travelState(store.route(), Rules.TravelState.empty(), travel) : Rules.TravelState.empty();
            loaded = new DayView(revision, events, incidents, travel, state);
          }
        } catch (RuntimeException failure) {
          android.util.Log.w("RailHistory", "Chưa đọc được dữ liệu ngày", failure);
        } finally {
          DayView result = loaded;
          runOnUiThread(() -> {
            pendingDays.remove(key);
            if (isFinishing() || !store.account().equals(account)) return;
            if (result != null) {
              // Keep only a small number of days; never mix another day's cached rows.
              if (dayViews.size() >= 4 && !dayViews.containsKey(key)) dayViews.clear();
              dayViews.put(key, result);
              if (day.equals(viewDay()) || day.equals(selected) || day.equals(historyDay))
                refreshContent();
            }
          });
        }
      });
    }
    return cached == null ? new DayView("", List.of(), List.of(), List.of(), Rules.TravelState.empty()) : cached;
  }

  private final Handler handler = new Handler(Looper.getMainLooper());
  private String lastUiState = "";
  private final Map<String, Integer> rowLimits = new HashMap<>();
  private Rules.Route viewRoute;
  private String viewRangeFrom, viewRangeTo;
  private List<Rules.Event> viewDayEvents, viewFaults;
  private Map<String, List<Rules.Event>> viewCrossingEvents;
  private final Runnable refresh =
      new Runnable() {
        public void run() {
          if (followToday) selected = LocalDate.now(WebSource.ZONE);
          if (historyFollowToday) historyDay = LocalDate.now(WebSource.ZONE);
          prepareLocalData();
          if (page.equals("settings") && voiceState != null)
            voiceState.setText(store.prefs.getString("voiceStatus", "Giọng đọc sử dụng tiếng Việt của điện thoại"));
          if (page.equals("overview")) updateReconnect();
          String state =
              store.prefs.getString("status", "")
                  + store.prefs.getLong("lastSuccess", 0)
                  + store.prefs.getLong("historyReadAt", 0)
                  + store.prefs.getLong("dataRevision", 0)
                  + store.prefs.getBoolean("running", false)
                  + store.prefs.getBoolean("connectionLost", false)
                  + store.monitoringDay()
                  + staleData()
                  + LocalDate.now(WebSource.ZONE);
          if (!state.equals(lastUiState)) {
            lastUiState = state;
            if (!page.equals("settings")) refreshContent();
          }
          handler.postDelayed(this, 2000);
        }
      };

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    store = new Store(this);
    selected = historyDay = store.monitoringDay();
    followToday = historyFollowToday = !store.historicalMonitoring();
    // Older builds could reopen in preview mode. The app now always opens live monitoring.
    store.prefs.edit().remove("demoUi").apply();
    demo = false;
    getWindow().setStatusBarColor(BG);
    getWindow().setNavigationBarColor(BG);
    if (Build.VERSION.SDK_INT >= 26) getWindow().getDecorView().setSystemUiVisibility(0);
    if (Build.VERSION.SDK_INT >= 33)
      requestPermissions(new String[] {"android.permission.POST_NOTIFICATIONS"}, 10);
    if (!demo
        && store.prefs.getBoolean("running", false)
        && !store.prefs.getString("url", "").isEmpty())
      startForegroundService(new Intent(this, MonitorService.class));
    render();
    prepareLocalData();
  }

  private void prepareLocalData() {
    if (preparingLocalData || io.isShutdown()) return;
    Store capturedStore = store;
    String capturedAccount = capturedStore.account();
    long now = System.currentTimeMillis();
    if (capturedStore.travelReady() && capturedStore.axleReady()
        && capturedStore.selfEvidenceReady() && capturedStore.faultRulesReady()
        && !capturedStore.historyCleanupDue(now)) return;
    preparingLocalData = true;
    io.execute(() -> {
      boolean prepared = false;
      try {
        synchronized (Store.class) {
          if (!capturedStore.account().equals(capturedAccount)) return;
          capturedStore.prepareFaultRules(capturedAccount, now);
          capturedStore.prepareSelfEvidence(capturedAccount, now);
          capturedStore.prepareTravelState(capturedAccount, now);
          if (!capturedStore.axleReady())
            capturedStore.updateActiveFaults(capturedAccount, Rules.faultBaseline(0, now), now,
                Rules.faultBaseline(capturedStore.prefs.getLong("baselineFrom", 0), now), List.of());
          capturedStore.maintainHistory(capturedAccount, now);
          prepared = true;
        }
      } catch (RuntimeException failure) {
        android.util.Log.w("RailHistory", "Chưa chuẩn bị được dữ liệu cục bộ", failure);
      } finally {
        boolean refreshReady = prepared;
        runOnUiThread(() -> {
          preparingLocalData = false;
          if (refreshReady && !isFinishing() && store == capturedStore
              && store.account().equals(capturedAccount)) refreshContent();
        });
      }
    });
  }

  @Override
  protected void onStart() {
    super.onStart();
    uiVisible = true;
    handler.post(refresh);
    startEffects();
  }

  @Override
  protected void onStop() {
    uiVisible = false;
    stopEffects();
    handler.removeCallbacks(refresh);
    super.onStop();
  }

  @Override
  protected void onDestroy() {
    stopEffects();
    io.shutdownNow();
    dataIo.shutdownNow();
    super.onDestroy();
  }

  @Override
  public void onWindowFocusChanged(boolean focused) {
    super.onWindowFocusChanged(focused);
    windowFocused = focused;
    if (focused) startEffects();
    else stopEffects();
  }

  /** One small animator; it never moves trains, fades data, or runs in the background. */
  private void startEffects() {
    if (!uiVisible || !windowFocused || !ValueAnimator.areAnimatorsEnabled()) return;
    if (lightPulse != null) return;
    lightLevel = -1;
    lightPulse = ValueAnimator.ofFloat(0.35f, 1f);
    lightPulse.setDuration(1400);
    lightPulse.setRepeatMode(ValueAnimator.REVERSE);
    lightPulse.setRepeatCount(ValueAnimator.INFINITE);
    lightPulse.addUpdateListener(
        a -> {
          float phase = (float) a.getAnimatedValue();
          int level = Math.round(phase * 40);
          if (level == lightLevel) return;
          lightLevel = level;
          if (headerMark != null) headerMark.setAlpha(0.78f + 0.22f * phase);
          if (summaryRing != null && summaryRing.alert) {
            summaryRing.phase = phase;
            summaryRing.invalidate();
          }
        });
    lightPulse.start();
  }

  private void stopEffects() {
    if (lightPulse != null) {
      lightPulse.cancel();
      lightPulse.removeAllUpdateListeners();
      lightPulse = null;
    }
    if (headerMark != null) headerMark.setAlpha(1f);
    if (summaryRing != null) {
      summaryRing.phase = 1f;
      summaryRing.invalidate();
    }
  }

  private int dp(float value) {
    return Math.round(value * getResources().getDisplayMetrics().density);
  }

  private LinearLayout column() {
    LinearLayout v = new LinearLayout(this);
    v.setOrientation(LinearLayout.VERTICAL);
    return v;
  }

  private LinearLayout row() {
    LinearLayout v = new LinearLayout(this);
    v.setGravity(Gravity.CENTER_VERTICAL);
    return v;
  }

  private TextView text(String value, int size, int color, boolean bold) {
    TextView v = new TextView(this);
    v.setText(value);
    v.setTextSize(size);
    v.setTextColor(color);
    v.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
    v.setIncludeFontPadding(false);
    v.setLineSpacing(dp(2), 1);
    return v;
  }

  private GradientDrawable shape(int color, int radius, int stroke) {
    GradientDrawable d = new GradientDrawable();
    d.setColor(color);
    d.setCornerRadius(dp(radius));
    if (stroke != 0) d.setStroke(dp(1), stroke);
    return d;
  }

  private GradientDrawable panel(int color, int accent) {
    GradientDrawable d =
        new GradientDrawable(
            GradientDrawable.Orientation.TL_BR, new int[] {color, blend(color, BG, 0.2f)});
    d.setCornerRadius(dp(12));
    d.setStroke(dp(1), accent == 0 ? LINE : blend(accent, color, 0.72f));
    return d;
  }

  private int blend(int a, int b, float amount) {
    return Color.rgb(
        Math.round(Color.red(a) * (1 - amount) + Color.red(b) * amount),
        Math.round(Color.green(a) * (1 - amount) + Color.green(b) * amount),
        Math.round(Color.blue(a) * (1 - amount) + Color.blue(b) * amount));
  }

  private void touch(View v, Runnable action) {
    Drawable base = v.getBackground();
    v.setBackground(
        new RippleDrawable(ColorStateList.valueOf(0x2700D9EF), base, shape(Color.WHITE, 10, 0)));
    v.setOnClickListener(w -> action.run());
    v.setClickable(true);
    v.setFocusable(true);
  }

  private void gap(LinearLayout parent, int height) {
    parent.addView(new View(this), new LinearLayout.LayoutParams(1, dp(height)));
  }

  private void divider(LinearLayout parent) {
    View v = new View(this);
    v.setBackgroundColor(LINE);
    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(1));
    p.topMargin = dp(7);
    p.bottomMargin = dp(7);
    parent.addView(v, p);
  }

  private TextView pill(String value, int color, int background) {
    TextView t = text(value, 10, color, true);
    t.setPadding(dp(9), dp(5), dp(9), dp(5));
    t.setBackground(shape(background, 8, 0));
    return t;
  }

  private LinearLayout card(int color) {
    LinearLayout c = column();
    c.setPadding(dp(12), dp(11), dp(12), dp(11));
    c.setBackground(panel(color, color == FAULT ? DANGER : color == GOOD ? GREEN : 0));
    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
    p.bottomMargin = dp(8);
    c.setLayoutParams(p);
    return c;
  }

  private View icon(String kind, int color, int size) {
    Icon v = new Icon(kind, color);
    v.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
    return v;
  }

  private View iconButton(String kind, String description, Runnable action) {
    LinearLayout b = row();
    b.setGravity(Gravity.CENTER);
    b.setBackground(shape(SURFACE, 14, LINE));
    b.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
    b.addView(icon(kind, BLUE, 21));
    b.setContentDescription(description);
    touch(b, action);
    return b;
  }

  private View action(String title, String kind, boolean primary, Runnable run) {
    LinearLayout b = row();
    b.setGravity(Gravity.CENTER);
    b.setPadding(dp(14), dp(12), dp(14), dp(12));
    b.setMinimumHeight(dp(46));
    if (primary) {
      GradientDrawable gradient =
          new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[] {BLUE, GREEN});
      gradient.setCornerRadius(dp(10));
      b.setBackground(gradient);
    } else b.setBackground(shape(TINT, 10, LINE));
    if (kind != null) {
      b.addView(icon(kind, primary ? BUTTON_TEXT : BLUE, 17));
      View spacer = new View(this);
      b.addView(spacer, new LinearLayout.LayoutParams(dp(8), 1));
    }
    b.addView(text(title, 13, primary ? BUTTON_TEXT : BLUE, true));
    touch(b, run);
    return b;
  }

  private String time(long at) {
    return DateTimeFormatter.ofPattern("HH:mm:ss")
        .withZone(WebSource.ZONE)
        .format(Instant.ofEpochMilli(at));
  }

  private List<Rules.Event> samples() {
    List<Rules.Event> values =
        new ArrayList<>(
            List.of(
                new Rules.Event("d6", demoClock - 365000, "Km 320+445", "Tàu lẻ", false, List.of()),
                new Rules.Event(
                    "d7", demoClock - 285000, "Km 313+800", "Tàu chẵn", false, List.of()),
                new Rules.Event(
                    "d8",
                    demoClock - 420000,
                    "Km 334+830",
                    "Mất nguồn xoay chiều 220VAC",
                    true,
                    List.of()),
                new Rules.Event(
                    "d9",
                    demoClock - 390000,
                    "Km 334+830",
                    "Nguồn xoay chiều 220VAC khôi phục tốt",
                    false,
                    List.of()),
                new Rules.Event(
                    "d10", demoClock - 215000, "Km 321+780", "Chuông 2 hỏng", true, List.of()),
                new Rules.Event("d1", demoClock - 45000, "Km 321+780", "Tàu lẻ", false, List.of()),
                new Rules.Event(
                    "d2",
                    demoClock - 125000,
                    "Km 328+325",
                    "Điện áp cảm biến 6 < 5V",
                    true,
                    List.of()),
                new Rules.Event(
                    "d3",
                    demoClock - 185000,
                    "Km 313+456",
                    "Cần chắn 1 mất trạng thái",
                    true,
                    List.of()),
                new Rules.Event("d4", demoClock - 245000, "Km 320+957", "Tàu lẻ", false, List.of()),
                new Rules.Event(
                    "d5",
                    demoClock - 310000,
                    "Km 313+800",
                    "Khôi phục hệ thống",
                    false,
                    List.of("46", "46", "48", "44", "46", "46"))));
    values.sort(Comparator.comparingLong(Rules.Event::at).reversed());
    return values;
  }

  private Rules.Route route() {
    if (viewRoute == null) viewRoute = demo ? Rules.DEMO_ROUTE : store.route();
    return viewRoute;
  }

  private String rangeFrom() {
    if (viewRangeFrom == null) viewRangeFrom = store.rangeFrom(route(), demo);
    return viewRangeFrom;
  }

  private String rangeTo() {
    if (viewRangeTo == null) viewRangeTo = store.rangeTo(route(), demo);
    return viewRangeTo;
  }

  private boolean inScope(String crossing) {
    return route().inRange(crossing, rangeFrom(), rangeTo());
  }

  private LocalDate viewDay() {
    if (page.equals("detail") && detailDay != null)
      return detailFollowToday ? LocalDate.now(WebSource.ZONE) : detailDay;
    if (page.equals("crossingHistory")) return historyDay;
    if (page.equals("incidents")) return selected;
    return store.monitoringDay();
  }

  private boolean historicalView() { return !viewDay().equals(LocalDate.now(WebSource.ZONE)); }

  private long monitoringStart() {
    return viewDay().atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli();
  }

  private long monitoringEnd() {
    return historicalView()
        ? viewDay().plusDays(1).atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli()
        : System.currentTimeMillis() + 1;
  }

  private long displayedLastSuccess() {
    if (!historicalView()) return store.prefs.getLong("lastSuccess", 0);
    return store.prefs.getLong("completeDay:" + viewDay(), 0);
  }

  private List<Rules.Event> allToday() {
    if (viewDayEvents == null)
      viewDayEvents =
          demo
              ? samples()
              : dayData(viewDay()).events();
    return viewDayEvents;
  }

  /** Reuse one data snapshot during a view update; every poll/navigation reads fresh data. */
  private void invalidateViewData() {
    viewRoute = null;
    viewRangeFrom = viewRangeTo = null;
    viewDayEvents = viewFaults = null;
    viewCrossingEvents = null;
  }

  private List<Rules.Event> occupancyEvents() {
    if (!demo && historicalView())
      return dayData(viewDay()).travelEvents();
    if (!demo && store.prefs.contains("occupiedPoints")) return store.occupationEvents();
    return demo ? samples() : dayData(viewDay()).events();
  }

  private boolean staleData() {
    if (demo) return false;
    if (store.historicalMonitoring()) return true;
    long last = displayedLastSuccess();
    String message = store.prefs.getString("status", "");
    return last == 0
        || System.currentTimeMillis() - last
            > Math.max(60000L, 2000L * Rules.POLL_SECONDS)
        || !(message.equals("Đã cập nhật") || message.startsWith("Đã đặt lại theo dõi"));
  }

  private List<Rules.Event> today() {
    List<Rules.Event> selected = new ArrayList<>();
    for (Rules.Event e : allToday()) if (inScope(e.crossing())) selected.add(e);
    return selected;
  }

  private boolean applyScope(String from, String to) {
    if (!route().validRange(from, to)) {
      Toast.makeText(
              this,
              "Đường ngang bắt đầu phải ở phía Bắc hoặc trùng điểm kết thúc",
              Toast.LENGTH_LONG)
          .show();
      return false;
    }
    store
        .prefs
        .edit()
        .putString(Store.rangeKey(demo, true), from)
        .putString(Store.rangeKey(demo, false), to)
        .apply();
    invalidateViewData();
    if (!demo)
      for (Rules.Event e : activeFaults())
        if (!inScope(e.crossing()))
          getSystemService(NotificationManager.class)
              .cancel(100 + Math.floorMod(e.id().hashCode(), 1000000));
    return true;
  }

  private List<Rules.Event> activeFaults() {
    if (viewFaults != null) return viewFaults;
    if (demo) return viewFaults = Rules.activeFaults(samples());
    if (historicalView()) {
      var records = new ArrayList<>(allToday());
      if (!Rules.selfTriggerEnabled(Rules.POLL_SECONDS)) records.removeIf(Rules::isSelfTrigger);
      return viewFaults = Rules.activeFaults(records);
    }
    long baseline =
        Rules.faultBaseline(store.prefs.getLong("baselineFrom", 0), System.currentTimeMillis());
    List<Rules.Event> current = new ArrayList<>();
    List<Rules.Event> records =
        store.prefs.contains("activeFaults")
            ? store.activeFaults()
            : dayData(viewDay()).events();
    boolean selfEnabled = Rules.selfTriggerEnabled(Rules.POLL_SECONDS);
    for (var event : records)
      if ((event.at() >= baseline
              || Rules.isAxleFault(event)
                  && event.at() >= Rules.faultBaseline(0, System.currentTimeMillis()))
          && (selfEnabled || !Rules.isSelfTrigger(event))) current.add(event);
    return viewFaults = Rules.activeFaults(current);
  }

  private List<Rules.Event> scopedFaults() {
    List<Rules.Event> result = new ArrayList<>();
    for (var event : activeFaults()) if (inScope(event.crossing())) result.add(event);
    return result;
  }

  private List<Rules.Event> faultsAt(String point) {
    List<Rules.Event> result = new ArrayList<>();
    for (var event : activeFaults())
      if (Rules.km(event.crossing()).equals(Rules.km(point))) result.add(event);
    return result;
  }

  private void navigate(String next) {
    if (page.equals(next)) return;
    page = next;
    render();
    if (ValueAnimator.areAnimatorsEnabled()) {
      content.setTranslationY(dp(4));
      content.animate().translationY(0).setDuration(140).start();
    }
  }

  private void render() {
    invalidateViewData();
    summaryCard = null;
    summaryConfirm = null;
    reconnectPanel = null;
    reconnectButton = null;
    summaryRing = null;
    routeWrapper = null;
    routeView = null;
    pageScroll = null;
    screen = column();
    screen.setBackgroundColor(BG);
    setContentView(screen);
    LinearLayout header = column();
    header.setPadding(dp(14), dp(8), dp(14), dp(10));
    header.setBackground(
        new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0xFF162238, BG}));
    LinearLayout titleRow = row();
    ImageView mark = new ImageView(this);
    headerMark = mark;
    mark.setImageResource(R.drawable.ic_train_header);
    mark.setPadding(dp(6), dp(6), dp(6), dp(6));
    mark.setBackground(panel(TINT, BLUE));
    mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
    mark.setContentDescription("Biểu tượng Giám sát Đường ngang");
    titleRow.addView(mark, new LinearLayout.LayoutParams(dp(34), dp(36)));
    LinearLayout titles = column();
    titles.setPadding(dp(10), 0, dp(4), 0);
    String heading =
        page.equals("overview")
            ? "Giám sát Đường ngang"
            : page.equals("incidents")
                ? "Sự cố đường ngang"
                : page.equals("settings")
                    ? "Cài đặt"
                    : page.equals("crossingHistory")
                        ? "Lịch sử đường ngang"
                        : page.equals("detail")
                        ? "Chi tiết đường ngang"
                        : page.equals("trains") ? "Các lượt tàu" : "Danh sách đường ngang";
    LinearLayout headingRow = row();
    TextView title = text(heading, 16, INK, true);
    title.setSingleLine(true);
    title.setEllipsize(android.text.TextUtils.TruncateAt.END);
    headingRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
    liveBadge = pill("", BLUE, TINT);
    liveBadge.setTextSize(7);
    liveBadge.setPadding(dp(5), dp(3), dp(5), dp(3));
    headingRow.addView(liveBadge);
    titles.addView(headingRow);
    gap(titles, 4);
    titles.addView(text("Công ty CP TTTH Đường sắt Vinh", 10, MUTED, false));
    titleRow.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
    titleRow.addView(
        iconButton(
            page.equals("detail") || page.equals("crossingHistory") || page.equals("trains")
                ? "back"
                : page.equals("settings") ? "close" : "settings",
            page.equals("settings") ? "Về tổng quan" : "Cài đặt",
            () ->
                navigate(
                    page.equals("trains")
                        ? "overview"
                        : page.equals("crossingHistory")
                            ? "detail"
                        : page.equals("detail")
                            ? "crossings"
                            : page.equals("settings") ? "overview" : "settings")));
    header.addView(titleRow);
    screen.addView(header);
    content = column();
    content.setPadding(dp(14), page.equals("overview") ? 0 : dp(8), dp(14), 0);
    if (page.equals("overview")) {
      LinearLayout summaryWrapper = column();
      summaryWrapper.setPadding(dp(14), dp(3), dp(14), 0);
      summaryWrapper.addView(overviewSummary());
      screen.addView(summaryWrapper);
      screen.addView(reconnectControls());
      LinearLayout map = routeCard();
      routeWrapper = column();
      routeWrapper.setPadding(dp(14), dp(4), dp(14), 0);
      routeWrapper.addView(map);
      screen.addView(routeWrapper);
    }
    if (page.equals("overview")) {
      content = new DashboardView();
      screen.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
    } else {
      pageScroll = new ScrollView(this);
      pageScroll.setClipToPadding(false);
      pageScroll.setFillViewport(true);
      pageScroll.setVerticalScrollBarEnabled(false);
      pageScroll.addView(content);
      screen.addView(pageScroll, new LinearLayout.LayoutParams(-1, 0, 1));
      if (page.equals("incidents")) incidents();
      else if (page.equals("crossings")) crossingList();
      else if (page.equals("detail")) crossingDetail();
      else if (page.equals("crossingHistory")) crossingHistory();
      else if (page.equals("trains")) trainList();
      else settings();
    }
    status = text("", 11, MUTED, false);
    status.setMaxLines(2);
    status.setEllipsize(android.text.TextUtils.TruncateAt.END);
    if (!page.equals("settings")) {
      if (page.equals("overview")) screen.addView(status);
      else content.addView(status);
      updateStatusLine();
    }
    if (page.equals("settings")) {
      TextView credit = text("Designed by Cao Xuân Cường", 8, MUTED, true);
      credit.setGravity(Gravity.END);
      credit.setPadding(dp(16), dp(3), dp(16), dp(5));
      screen.addView(credit);
    }
    navigation();
    updateLiveBadge();
    startEffects();
  }

  private void updateLiveBadge() {
    boolean known = displayedLastSuccess() > 0;
    boolean running = store.prefs.getBoolean("running", false);
    boolean live = known && running && !staleData() && !store.prefs.getBoolean("connectionLost", false);
    liveBadge.setText(historicalView() ? "LỊCH SỬ" : !known ? "CHỜ" : !running ? "DỪNG" : live ? "LIVE" : "CŨ");
    liveBadge.setTextColor(live ? BLUE : WARNING);
    liveBadge.setContentDescription(live ? "Dữ liệu web đang cập nhật" : "Dữ liệu chưa trực tuyến");
    navHasFault = !scopedFaults().isEmpty();
    if (incidentTabIcon != null) incidentTabIcon.invalidate();
  }

  private View reconnectControls() {
    LinearLayout wrapper = column();
    wrapper.setPadding(dp(14), 0, dp(14), dp(2));
    reconnectPanel = column();
    reconnectPanel.setPadding(dp(8), dp(3), dp(8), dp(3));
    LinearLayout line = row();
    connectionProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
    connectionProgress.setIndeterminate(true);
    connectionProgress.setContentDescription("Đang tải dữ liệu");
    var progressSize = new LinearLayout.LayoutParams(dp(14), dp(14));
    progressSize.rightMargin = dp(6);
    line.addView(connectionProgress, progressSize);
    connectionState = text("", 10, MUTED, false);
    line.addView(connectionState, new LinearLayout.LayoutParams(0, -2, 1));
    TextView retry = text("Kết nối lại", 10, RED, true);
    retry.setGravity(Gravity.CENTER);
    retry.setPadding(dp(9), dp(5), dp(9), dp(5));
    retry.setMinimumHeight(dp(34));
    retry.setBackground(shape(FAULT_TINT, 7, RED));
    retry.setContentDescription("Kết nối lại");
    touch(retry, () -> startForegroundService(
        new Intent(this, MonitorService.class).setAction("RETRY_CONNECTION")));
    reconnectButton = retry;
    line.addView(retry, new LinearLayout.LayoutParams(-2, -2));
    line.setMinimumHeight(dp(24));
    reconnectPanel.addView(line);
    connectionWarning = text("Mất kết nối", 9, RED, true);
    connectionWarning.setGravity(Gravity.END);
    reconnectPanel.addView(connectionWarning);
    wrapper.addView(reconnectPanel);
    updateReconnect();
    return wrapper;
  }

  private void updateReconnect() {
    if (reconnectPanel == null) return;
    boolean running = store.prefs.getBoolean("running", false);
    boolean lost = running && store.prefs.getBoolean("connectionLost", false);
    boolean loading = running && store.prefs.getBoolean("dataLoading", false);
    reconnectButton.setVisibility(lost ? View.VISIBLE : View.GONE);
    connectionWarning.setVisibility(lost ? View.VISIBLE : View.GONE);
    reconnectButton.setEnabled(!loading);
    reconnectButton.setAlpha(loading ? 0.5f : 1f);
    connectionProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
    connectionProgress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(lost ? RED : BLUE));
    connectionState.setText(!running ? "Đã dừng theo dõi"
        : lost ? loading ? "Đang kết nối lại…" : "Tự thử lại mỗi 2 phút"
        : loading ? "Đang tải dữ liệu…"
        : store.historicalMonitoring() && store.prefs.getLong("historyReadAt", 0) > 0 ? "Đã tải lịch sử"
        : displayedLastSuccess() > 0 && !staleData() ? "Đã kết nối · " + time(displayedLastSuccess())
        : "Chờ cập nhật dữ liệu");
    connectionState.setTextColor(lost ? RED : loading ? BLUE : MUTED);
    reconnectPanel.setBackground(shape(TINT, 7, lost ? RED : LINE));
  }

  private void updateStatusLine() {
    String message = store.prefs.getString("status", "");
    if (page.equals("crossingHistory") || page.equals("incidents")) {
      LocalDate shown = page.equals("crossingHistory") ? historyDay : selected;
      if (!shown.equals(store.monitoringDay()))
        message = (store.dayComplete(shown) ? "Đã tải ngày " : "Chưa tải đủ ngày ")
            + shown.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }
    status.setText(message);
    status.setVisibility(message.isEmpty() ? View.GONE : View.VISIBLE);
    // Overview already shows freshness in its summary and diagram. Keep only actionable messages.
    if (page.equals("overview") && message.equals("Đã cập nhật")) status.setVisibility(View.GONE);
    status.setPadding(dp(14), dp(2), dp(14), dp(5));
    status.setTextSize(9);
  }

  /** A poll changes data inside the existing window, never replaces its root/header/navigation. */
  private void refreshContent() {
    if (page.equals("settings")) return;
    invalidateViewData();
    updateLiveBadge();
    if (page.equals("overview")) {
      updateReconnect();
      updateSummary();
      if (!renderedRoute.equals(route().points())) {
        routeWrapper.removeAllViews();
        routeWrapper.addView(routeCard());
      } else updateRoutePresentation();
      updateStatusLine();
      if (content.getHeight() > 0) fillDashboard(content, content.getHeight());
    } else {
      ScrollView currentScroll = pageScroll;
      int x = currentScroll.getScrollX(), y = currentScroll.getScrollY();
      content.removeAllViews();
      if (page.equals("incidents")) incidents();
      else if (page.equals("crossings")) crossingList();
      else if (page.equals("detail")) crossingDetail();
      else if (page.equals("crossingHistory")) crossingHistory();
      else if (page.equals("trains")) trainList();
      content.addView(status);
      updateStatusLine();
      // Restore after measuring the new rows, before the next frame is drawn.
      currentScroll
          .getViewTreeObserver()
          .addOnPreDrawListener(
              new android.view.ViewTreeObserver.OnPreDrawListener() {
                public boolean onPreDraw() {
                  currentScroll.getViewTreeObserver().removeOnPreDrawListener(this);
                  currentScroll.scrollTo(x, y);
                  return true;
                }
              });
    }
  }

  private LinearLayout overviewSummary() {
    summaryCard = card(GOOD);
    summaryCard.setPadding(dp(10), dp(7), dp(10), dp(7));
    ((LinearLayout.LayoutParams) summaryCard.getLayoutParams()).bottomMargin = dp(4);
    summaryCard.setOrientation(LinearLayout.HORIZONTAL);
    summaryCard.setGravity(Gravity.CENTER_VERTICAL);
    summaryRing = new SummaryRing();
    summaryCard.addView(summaryRing, new LinearLayout.LayoutParams(dp(36), dp(36)));
    LinearLayout words = column();
    words.setPadding(dp(9), 0, 0, 0);
    summaryTitle = text("", 10, GREEN, true);
    summaryDetail = text("", 14, INK, true);
    summaryTime = text("", 9, MUTED, false);
    words.addView(summaryTitle);
    gap(words, 2);
    words.addView(summaryDetail);
    gap(words, 2);
    words.addView(summaryTime);
    summaryCard.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
    summaryConfirm = action("XÁC NHẬN", null, false, () -> {
      if (!store.prefs.getBoolean("running", false)) return;
      startService(new Intent(this, MonitorService.class).setAction("MUTE_ALARM"));
      Toast.makeText(this, "Đã xác nhận lượt cảnh báo hiện tại", Toast.LENGTH_SHORT).show();
    });
    summaryConfirm.setTag("confirm-current-alerts");
    summaryConfirm.setPadding(dp(10), dp(8), dp(10), dp(8));
    summaryConfirm.setMinimumHeight(dp(44));
    summaryConfirm.setContentDescription("XÁC NHẬN lượt cảnh báo hiện tại");
    summaryCard.addView(summaryConfirm, new LinearLayout.LayoutParams(-2, -2));
    updateSummary();
    return summaryCard;
  }

  private void updateSummary() {
    if (summaryCard == null) return;
    int total = 0;
    for (String point : route().crossings()) if (inScope(point)) total++;
    int faults = scopedFaults().size();
    boolean known = displayedLastSuccess() > 0;
    boolean running = store.prefs.getBoolean("running", false);
    summaryConfirm.setVisibility(faults > 0 && running && !store.historicalMonitoring()
        ? View.VISIBLE : View.GONE);
    int color = !known || staleData() ? WARNING : faults > 0 ? RED : running ? GREEN : WARNING;
    summaryCard.setBackground(
        panel(
            faults > 0 ? FAULT : !known || staleData() ? TINT : GOOD, faults > 0 ? DANGER : color));
    summaryTitle.setText(
        !known
            ? "CHỜ KẾT NỐI"
            : !running
                ? "ĐÃ DỪNG THEO DÕI"
                : store.historicalMonitoring() ? "ĐANG XEM LỊCH SỬ"
                : staleData()
                    ? "CẦN KIỂM TRA CẬP NHẬT"
                    : faults > 0 ? "CÓ SỰ CỐ" : "ĐANG THEO DÕI");
    summaryTitle.setTextColor(color);
    summaryDetail.setText(
        !known
            ? "Kết nối tài khoản để theo dõi"
            : faults > 0
                ? faults + " sự cố chưa khôi phục"
                : total + " đường ngang · Chưa ghi nhận lỗi mới");
    long last = displayedLastSuccess();
    int interval = Rules.POLL_SECONDS;
    summaryTime.setText(
        (store.historicalMonitoring() ? "Lịch sử " + store.monitoringDay().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " · " : "")
            + (last == 0 ? "Chưa có dữ liệu từ website" : "Cập nhật " + time(last))
            + " · "
            + (store.prefs.getBoolean("connectionLost", false) ? "Thử lại mỗi 2 phút"
                : interval < 60 ? interval + " giây" : interval / 60 + " phút"));
    summaryRing.number = faults > 0 ? faults : total;
    summaryRing.color = color;
    summaryRing.alert = faults > 0;
    summaryRing.invalidate();
  }

  private class SummaryRing extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface face = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    int number, color;
    boolean alert;
    float phase = 1f;

    SummaryRing() {
      super(MainActivity.this);
    }

    protected void onDraw(Canvas canvas) {
      float cx = getWidth() / 2f, cy = getHeight() / 2f, radius = Math.min(cx, cy) - dp(5);
      paint.setStyle(Paint.Style.STROKE);
      paint.setColor(alert ? DANGER : color);
      paint.setAlpha((int) (25 + (alert ? phase : 0.5f) * 35));
      paint.setStrokeWidth(dp(9));
      canvas.drawCircle(cx, cy, radius, paint);
      paint.setAlpha(255);
      paint.setStrokeWidth(dp(2.5f));
      paint.setColor(color);
      canvas.drawCircle(cx, cy, radius, paint);
      paint.setStyle(Paint.Style.FILL);
      paint.setTextSize(dp(16));
      paint.setTypeface(face);
      String text = "" + number;
      if (paint.measureText(text) > dp(23))
        paint.setTextSize(paint.getTextSize() * dp(23) / paint.measureText(text));
      canvas.drawText(
          text,
          cx - paint.measureText(text) / 2,
          cy - (paint.ascent() + paint.descent()) / 2,
          paint);
    }
  }

  private Rules.TravelState diagramState() {
    if (!demo && !Rules.diagramEnabled(Rules.POLL_SECONDS)) return Rules.TravelState.empty();
    if (!demo && store.historicalMonitoring())
      return dayData(store.monitoringDay()).travel();
    if (!demo) return store.travelState();
    return Rules.travelState(route(), Rules.TravelState.empty(), samples());
  }

  private void updateRoutePresentation() {
    List<String> points = route().points();
    routeView.setContentDescription(
        "Toàn tuyến, gồm "
            + route().crossings().size()
            + " đường ngang và "
            + (points.size() - route().crossings().size())
            + " ga, "
            + Rules.approachingCrossings(diagramState()).size()
            + " điểm tiếp cận, "
            + Rules.trackSegments(route(), diagramState()).size()
            + " đoạn tàu"
            + (demo
                ? " · Dữ liệu minh họa"
                : staleData() ? " · Dữ liệu cũ hoặc chưa cập nhật" : " · Theo bản tin web"));
    routeView.updateOccupancy();
    long last = displayedLastSuccess();
    routeNote.setText(
        demo
            ? "Minh họa"
            : store.historicalMonitoring()
                ? "Lịch sử " + store.monitoringDay().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")) + (last == 0 ? " · Chưa tải" : " · Đã tải " + time(last))
            : !store.travelReady()
                ? "Đang cập nhật sơ đồ"
                : last == 0
                    ? "Chưa cập nhật từ web"
                    : (staleData() ? "Dữ liệu cũ · " : "Theo bản tin web · ") + time(last));
    if (!demo && !Rules.diagramEnabled(Rules.POLL_SECONDS))
      routeNote.setText("Sơ đồ chạy tàu chỉ hoạt động ở chu kỳ 30 giây");
    routeNote.setTextColor(!demo && staleData() ? WARNING : MUTED);
  }

  private LinearLayout routeCard() {
    LinearLayout c = card(SURFACE);
    c.setPadding(dp(12), dp(7), dp(12), dp(7));
    c.setBackground(panel(SURFACE, BLUE));
    LinearLayout compass = row();
    compass.setPadding(0, 0, 0, 0);
    compass.addView(text("BẮC", 9, MUTED, true));
    compass.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
    compass.addView(text("NAM", 9, MUTED, true));
    c.addView(compass);
    routeView = new RouteView();
    List<String> points = route().points();
    renderedRoute = List.copyOf(points);
    {
      int routeWidth = dp(60 + (points.size() > 13 ? 26 : 22) * Math.max(0, points.size() - 1));
      routeView.setMinimumWidth(routeWidth);
      HorizontalScrollView scroll = new HorizontalScrollView(this);
      scroll.setFillViewport(true);
      scroll.addView(routeView, new HorizontalScrollView.LayoutParams(routeWidth, routeView.preferredHeight()));
      c.addView(scroll, new LinearLayout.LayoutParams(-1, routeView.preferredHeight() + dp(4)));
    }
    routeNote = text("", 8, MUTED, false);
    routeNote.setGravity(Gravity.END);
    c.addView(routeNote);
    updateRoutePresentation();
    return c;
  }

  private void setAlarmSound(boolean enabled) {
    setAlertMode(enabled ? store.prefs.getString("audibleMode", AlertOptions.VOICE) : AlertOptions.SILENT);
  }

  private void setAlertMode(String mode) {
    store.setAlertMode(mode);
    if (store.prefs.getBoolean("running", false))
      startService(new Intent(this, MonitorService.class).setAction("MUTE_ALARM"));
    if (AlertOptions.SILENT.equals(store.alertMode())) {
      NotificationManager manager = getSystemService(NotificationManager.class);
      for (var notification : manager.getActiveNotifications())
        if (notification.getId() != 1) manager.cancel(notification.getId());
    }
  }

  /** The main dashboard owns the available viewport; it never adds a vertical scroller. */
  private class DashboardView extends LinearLayout {
    private int lastWidth = -1, lastHeight = -1;

    DashboardView() {
      super(MainActivity.this);
      setOrientation(VERTICAL);
      setPadding(dp(14), 0, dp(14), 0);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
      int width = MeasureSpec.getSize(widthSpec), height = MeasureSpec.getSize(heightSpec);
      // Build before drawing the first frame, instead of posting an empty dashboard frame.
      if (height > 0 && (width != lastWidth || height != lastHeight || getChildCount() == 0)) {
        lastWidth = width;
        lastHeight = height;
        fillDashboard(this, height);
      }
      super.onMeasure(widthSpec, heightSpec);
    }
  }

  private void fillDashboard(LinearLayout panel, int height) {
    boolean reuseCards = panel.getChildCount() == 2;
    LinearLayout previousTrain = reuseCards ? (LinearLayout) panel.getChildAt(0) : null;
    LinearLayout previousFault = reuseCards ? (LinearLayout) panel.getChildAt(1) : null;
    if (!reuseCards) panel.removeAllViews();
    List<Rules.Event> trains = new ArrayList<>();
    for (Rules.Event e : today()) if (Rules.direction(e.text()) != 0) trains.add(e);
    List<Rules.Event> faults = scopedFaults();
    float density = getResources().getDisplayMetrics().density,
        scale = getResources().getConfiguration().fontScale;
    float available = height / density;
    int tn = Math.min(trains.size(), expanded ? 10 : 6), fn = Math.min(faults.size(), 6);
    float trainRow = 34 * Math.max(1, scale), faultRow = 66 * Math.max(1, scale);
    while (142 + Math.max(1, tn) * trainRow + Math.max(1, fn) * faultRow > available
        && (tn > 1 || fn > 1)) {
      if (expanded && fn > 2) fn--;
      else if (tn > 1 && (fn <= 1 || tn >= fn)) tn--;
      else if (fn > 1) fn--;
      else tn--;
    }
    float trainNeed = 58 + Math.max(1, tn) * trainRow,
        faultNeed = fn == 0 ? 78 : 72 + fn * faultRow;
    float trainActual = (available - 8) * trainNeed / (trainNeed + faultNeed),
        faultActual = available - 8 - trainActual;
    boolean roomyTrain = (trainActual - 48) / Math.max(1, tn) > 46,
        roomyFault = (faultActual - 56) / Math.max(1, fn) > 68;
    LinearLayout train = reuseCards ? previousTrain : card(SURFACE);
    train.removeAllViews();
    LinearLayout.LayoutParams trainParams = new LinearLayout.LayoutParams(-1, 0, trainNeed);
    trainParams.bottomMargin = dp(8);
    if (reuseCards) train.setLayoutParams(trainParams);
    else panel.addView(train, trainParams);
    LinearLayout th = row();
    th.addView(icon("direction", BLUE, 19));
    TextView tt = text("Tàu gần nhất", 13, INK, true);
    tt.setPadding(dp(8), 0, 0, 0);
    th.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
    if (trains.size() > tn || expanded) {
      LinearLayout more = row();
      more.addView(icon(expanded ? "up" : "down", MUTED, 17));
      more.setPadding(dp(8), dp(4), dp(2), dp(4));
      more.setContentDescription(expanded ? "Thu gọn lượt tàu" : "Hiển thị thêm lượt tàu");
      touch(
          more,
          () -> {
            expanded = !expanded;
            fillDashboard(panel, panel.getHeight());
          });
      th.addView(more);
    } else th.addView(pill("" + trains.size(), BLUE, TINT));
    train.addView(th);
    gap(train, 6);
    if (tn == 0) {
      LinearLayout placeholder = column();
      placeholder.setGravity(Gravity.CENTER_VERTICAL);
      empty(
          placeholder, "Chưa ghi nhận tàu", "Thông tin xuất hiện khi có dữ liệu mới.", "direction");
      train.addView(placeholder, new LinearLayout.LayoutParams(-1, 0, 1));
    }
    for (int i = 0; i < tn; i++) {
      if (i > 0) dashboardDivider(train);
      LinearLayout entry = compactTrainRow(trains.get(i), i == 0);
      train.addView(entry, new LinearLayout.LayoutParams(-1, 0, 1));
    }
    if (trains.size() > tn) {
      TextView more = text("Xem tất cả lượt tàu  →", 10, BLUE, true);
      more.setPadding(0, dp(5), 0, dp(3));
      touch(more, () -> navigate("trains"));
      train.addView(more);
    }
    LinearLayout fault = reuseCards ? previousFault : card(FAULT);
    fault.removeAllViews();
    LinearLayout.LayoutParams faultParams =
        fn == 0
            ? new LinearLayout.LayoutParams(-1, dp(78))
            : new LinearLayout.LayoutParams(-1, 0, faultNeed);
    if (reuseCards) fault.setLayoutParams(faultParams);
    else panel.addView(fault, faultParams);
    LinearLayout fh = row();
    fh.addView(icon("alert", RED, 19));
    TextView ft = text("Sự cố", 13, INK, true);
    ft.setPadding(dp(8), 0, dp(8), 0);
    fh.addView(ft);
    fh.addView(pill(String.format(Locale.ROOT, "%02d", faults.size()), RED, FAULT_TINT));
    fh.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
    boolean sound = store.prefs.getBoolean("sound", true);
    LinearLayout mute = row();
    mute.setPadding(dp(8), dp(6), dp(8), dp(6));
    mute.setGravity(Gravity.CENTER);
    mute.setBackground(shape(FAULT_TINT, 10, 0));
    mute.addView(icon(sound ? "bell" : "mute", RED, 17));
    TextView muteText = text(sound ? "Tắt âm thanh" : "Bật âm thanh", 10, RED, true);
    muteText.setPadding(dp(5), 0, 0, 0);
    mute.addView(muteText);
    mute.setContentDescription(sound ? "Tắt chuông, giọng đọc và rung" : "Bật âm thanh cảnh báo");
    touch(
        mute,
        () -> {
          setAlarmSound(!sound);
          fillDashboard(panel, panel.getHeight());
        });
    fh.addView(mute);
    fault.addView(fh);
    gap(fault, 5);
    if (fn == 0) {
      TextView empty =
          text(
              displayedLastSuccess() > 0 ? "Không có sự cố" : "Đang chờ dữ liệu",
              11,
              MUTED,
              false);
      fault.addView(empty);
    }
    for (int i = 0; i < fn; i++) {
      if (i > 0) gap(fault, 4);
      LinearLayout entry = dashboardEntry(faults.get(i), true, roomyFault);
      fault.addView(entry, new LinearLayout.LayoutParams(-1, 0, 1));
    }
    TextView moreFaults = text("Xem tất cả sự cố (" + faults.size() + ")  →", 10, BLUE, true);
    moreFaults.setPadding(0, dp(5), 0, dp(3));
    touch(moreFaults, () -> navigate("incidents"));
    if (fn > 0) fault.addView(moreFaults);
  }

  private LinearLayout compactTrainRow(Rules.Event event, boolean latest) {
    LinearLayout line = row();
    View dot = new View(this);
    dot.setBackground(shape(latest ? GREEN : MUTED, 8, 0));
    LinearLayout.LayoutParams point = new LinearLayout.LayoutParams(dp(6), dp(6));
    point.rightMargin = dp(7);
    line.addView(dot, point);
    line.addView(
        text(time(event.at()), 10, MUTED, false), new LinearLayout.LayoutParams(dp(59), -2));
    TextView km = text("Km " + Rules.km(event.crossing()), 13, INK, true);
    line.addView(km, new LinearLayout.LayoutParams(0, -2, 1));
    TextView direction =
        pill(event.text() + (Rules.direction(event.text()) > 0 ? " →" : " ←"), GREEN, GOOD);
    direction.setTextSize(9);
    direction.setPadding(dp(5), dp(4), dp(5), dp(4));
    line.addView(direction);
    touch(line, () -> openCrossing(event.crossing()));
    return line;
  }

  private void dashboardDivider(LinearLayout parent) {
    View line = new View(this);
    line.setBackgroundColor(LINE);
    parent.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
  }

  private LinearLayout dashboardEntry(Rules.Event e, boolean fault, boolean roomy) {
    LinearLayout box = column();
    box.setGravity(Gravity.CENTER_VERTICAL);
    box.setPadding(dp(7), dp(5), dp(7), dp(5));
    box.setBackground(shape(0xFF341522, 7, FAULT_TINT));
    LinearLayout line = row();
    TextView clock = text(time(e.at()), 9, MUTED, true);
    clock.setTypeface(Typeface.MONOSPACE);
    clock.setSingleLine(true);
    line.addView(clock, new LinearLayout.LayoutParams(dp(57), -2));
    TextView name = text("Km " + Rules.km(e.crossing()), 12, RED, true);
    name.setSingleLine(true);
    name.setEllipsize(android.text.TextUtils.TruncateAt.END);
    line.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
    TextView badge = pill("Chưa khôi phục", RED, FAULT_TINT);
    badge.setTextSize(8);
    badge.setPadding(dp(5), dp(3), dp(5), dp(3));
    line.addView(badge);
    box.addView(line);
    gap(box, 4);
    int direction = Rules.direction(e.text());
    TextView message =
        text(
            e.text() + (direction > 0 ? "  →" : direction < 0 ? "  ←" : ""),
            11,
            fault ? RED : direction != 0 ? GREEN : MUTED,
            false);
    message.setMaxLines(2);
    message.setEllipsize(android.text.TextUtils.TruncateAt.END);
    box.addView(message);
    if (fault) {
      touch(
          box,
          () ->
              new AlertDialog.Builder(this)
                  .setTitle(time(e.at()) + " · " + e.crossing())
                  .setMessage(e.text() + "\n\nChưa khôi phục")
                  .setPositiveButton("Đóng", null)
                  .setNeutralButton(
                      "Chi tiết đường ngang", (dialog, which) -> openCrossing(e.crossing()))
                  .show());
    }
    return box;
  }

  private void trainList() {
    LinearLayout card = card(SURFACE);
    card.addView(text("Các lượt tàu trong phạm vi theo dõi", 13, INK, true));
    gap(card, 13);
    int count = 0;
    for (Rules.Event e : today())
      if (Rules.direction(e.text()) != 0) {
        if (count++ > 0) divider(card);
        eventRow(card, e, false);
      }
    if (count == 0)
      empty(card, "Chưa có lượt tàu", "Thông tin xuất hiện khi có dữ liệu mới.", "direction");
    content.addView(card);
  }

  private void eventRow(LinearLayout parent, Rules.Event e, boolean fault) {
    LinearLayout r = new LinearLayout(this);
    r.setGravity(Gravity.TOP);
    LinearLayout clock = column();
    TextView value = text(time(e.at()), 11, fault ? RED : MUTED, true);
    value.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    clock.addView(value);
    r.addView(clock, new LinearLayout.LayoutParams(dp(67), -2));
    LinearLayout details = column();
    details.addView(text(e.crossing(), 13, INK, true));
    gap(details, 3);
    int direction = Rules.direction(e.text());
    String message = direction == 0 ? e.text() : e.text() + (direction > 0 ? "  →" : "  ←");
    details.addView(text(message, 11, fault ? RED : direction != 0 ? GREEN : MUTED, false));
    r.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
    parent.addView(r);
  }

  private void empty(LinearLayout target, String title, String description, String kind) {
    LinearLayout r = row();
    LinearLayout disc = row();
    disc.setGravity(Gravity.CENTER);
    disc.setBackground(shape(TINT, 13, 0));
    disc.addView(
        icon(
            kind,
            kind.equals("shield") && (demo || displayedLastSuccess() > 0)
                ? GREEN
                : MUTED,
            22));
    r.addView(disc, new LinearLayout.LayoutParams(dp(44), dp(44)));
    LinearLayout words = column();
    words.setPadding(dp(12), 0, 0, 0);
    words.addView(text(title, 13, INK, true));
    gap(words, 5);
    if (!description.isEmpty()) words.addView(text(description, 11, MUTED, false));
    r.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
    target.addView(r);
  }

  private void incidents() {
    LinearLayout controls = card(SURFACE);
    LinearLayout date = row();
    date.addView(icon("calendar", BLUE, 17));
    TextView day = text(selected.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")), 13, INK, true);
    day.setPadding(dp(8), 0, 0, 0);
    date.addView(day, new LinearLayout.LayoutParams(0, -2, 1));
    TextView fetch = pill("Tải dữ liệu", BLUE, TINT);
    touch(fetch, this::loadHistory);
    date.addView(fetch);
    touch(day, () -> chooseHistoryDate(false));
    controls.addView(date);
    gap(controls, 10);
    LinearLayout filters = row();
    for (String name : List.of("Tất cả", "Chưa khôi phục", "Đã khôi phục")) {
      boolean active = incidentFilter.equals(name);
      int accent = name.equals("Chưa khôi phục") ? DANGER : BLUE;
      TextView pick = text(name, 10, active ? INK : MUTED, true);
      pick.setPadding(dp(5), dp(9), dp(5), dp(9));
      pick.setGravity(Gravity.CENTER);
      pick.setBackground(shape(active ? blend(accent, SURFACE, 0.35f) : Color.TRANSPARENT, 9, 0));
      filters.addView(pick, new LinearLayout.LayoutParams(0, -2, 1));
      touch(
          pick,
          () -> {
            incidentFilter = name;
            render();
          });
    }
    controls.addView(filters);
    content.addView(controls);
    long from = selected.atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli(),
        to = selected.plusDays(1).atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli();
    List<Rules.Event> records =
        demo && selected.equals(LocalDate.now(WebSource.ZONE))
            ? samples()
            : demo ? List.of() : dayData(selected).incidents();
    Set<String> openIds = new HashSet<>();
    if (selected.equals(LocalDate.now(WebSource.ZONE))) {
      records = new ArrayList<>(records);
      Set<String> present = new HashSet<>();
      for (var event : records) present.add(event.id());
      for (var event : activeFaults()) {
        openIds.add(event.id());
        if (!present.contains(event.id())) records.add(event);
      }
    }
    if (!Rules.selfTriggerEnabled(Rules.POLL_SECONDS)) {
      records = new ArrayList<>(records);
      records.removeIf(Rules::isSelfTrigger);
    }
    int shown = 0;
    long baseline = demo || !selected.equals(LocalDate.now(WebSource.ZONE)) ? 0 : store.prefs.getLong("baselineFrom", 0);
    String incidentLimitKey = dayKey(selected) + "|incidents|" + incidentFilter;
    int incidentLimit = rowLimits.getOrDefault(incidentLimitKey, 40), matchedIncidents = 0;
    for (Rules.Incident incident : Rules.incidentHistory(records)) {
      if ((!openIds.contains(incident.fault().id())
              && (incident.fault().at() < from || incident.fault().at() >= to))
          || !inScope(incident.fault().crossing())) continue;
      boolean recovered = incident.recovery() != null,
          reset =
              !recovered
                  && !Rules.isAxleFault(incident.fault())
                  && incident.fault().at() < baseline;
      if (incidentFilter.equals("Đã khôi phục") && !recovered) continue;
      if (incidentFilter.equals("Chưa khôi phục") && (recovered || reset)) continue;
      if (++matchedIncidents > incidentLimit) continue;
      LinearLayout item = card(recovered ? GOOD : reset ? SURFACE : FAULT);
      LinearLayout identity = row();
      TextView clock = text(time(incident.fault().at()), 10, MUTED, true);
      clock.setTypeface(Typeface.MONOSPACE);
      identity.addView(clock, new LinearLayout.LayoutParams(dp(66), -2));
      TextView name = text("Km " + Rules.km(incident.fault().crossing()), 14, INK, true);
      name.setSingleLine(true);
      name.setEllipsize(android.text.TextUtils.TruncateAt.END);
      identity.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
      identity.addView(
          icon(recovered ? "shield" : "alert", recovered ? GREEN : reset ? MUTED : RED, 17));
      item.addView(identity);
      gap(item, 8);
      // The entire original website message remains readable in the full incident list.
      item.addView(text(incident.fault().text(), 12, recovered ? INK : reset ? MUTED : RED, false));
      gap(item, 9);
      LinearLayout state = row();
      TextView badge =
          text(
              recovered
                  ? "✓ Đã khôi phục"
                  : reset
                      ? "Đã đặt lại theo dõi"
                      : Rules.isAxleFault(incident.fault())
                          ? "Cảnh báo đếm trục trong ngày"
                          : "Chưa khôi phục",
              11,
              recovered ? GREEN : reset ? MUTED : RED,
              true);
      state.addView(badge, new LinearLayout.LayoutParams(0, -2, 1));
      if (recovered) state.addView(text(time(incident.recovery().at()), 10, MUTED, false));
      item.addView(state);
      touch(item, () -> openCrossing(incident.fault().crossing()));
      content.addView(item);
      shown++;
    }
    if (matchedIncidents > incidentLimit)
      content.addView(action("Hiển thị thêm · " + shown + "/" + matchedIncidents + " sự cố", "history", true,
          () -> { rowLimits.put(incidentLimitKey, incidentLimit + 40); refreshContent(); }));
    if (shown == 0) {
      LinearLayout emptyCard = card(SURFACE);
      boolean complete = demo || dayLoaded(selected) && (selected.equals(LocalDate.now(WebSource.ZONE))
          ? displayedLastSuccess() > 0 : store.dayComplete(selected));
      empty(emptyCard, complete ? "Không có sự cố" : "Chưa tải đủ dữ liệu",
          complete ? "" : "Đợi tải xong hoặc chọn Tải dữ liệu để đọc đủ báo cáo ngày này.", "shield");
      content.addView(emptyCard);
    }
  }

  private void loadHistory() {
    LocalDate day = page.equals("crossingHistory") ? historyDay : selected;
    loadHistory(day);
  }

  private void loadHistory(LocalDate day) {
    if (day.isBefore(LocalDate.now(WebSource.ZONE).minusDays(29))
        || day.isAfter(LocalDate.now(WebSource.ZONE))) {
      Toast.makeText(this, "Chọn ngày trong 30 ngày gần nhất", Toast.LENGTH_SHORT).show();
      return;
    }
    if (demo) {
      Toast.makeText(this, "Dữ liệu minh họa không kết nối website", Toast.LENGTH_SHORT).show();
      return;
    }
    if (store.prefs.getString("url", "").isEmpty()) {
      navigate("settings");
      return;
    }
    String account = store.account();
    String request = account + "\n" + day;
    if (!loadingDays.add(request)) return;
    status.setText("Đang tải dữ liệu…");
    status.setVisibility(View.VISIBLE);
    io.execute(
        () -> {
          try {
            if (!store.account().equals(account)
                || !(page.equals("crossingHistory") ? historyDay : selected).equals(day)) return;
            WebSource source =
                new WebSource(
                    store.prefs.getString("url", ""),
                    store.prefs.getString("user", ""),
                    store.password());
            store.maintainHistory(account, System.currentTimeMillis());
            var data = source.readDay(day);
            var records = new ArrayList<>(data.events());
            if (day.isBefore(LocalDate.now(WebSource.ZONE))
                && !day.minusDays(1).isBefore(LocalDate.now(WebSource.ZONE).minusDays(29)))
              records.addAll(source.readDay(day.minusDays(1)).events());
            store.saveHistoricalDay(account, day, new WebSource.DayData(records, data.route()));
            long now = System.currentTimeMillis();
            if (day.equals(LocalDate.now(WebSource.ZONE)))
              store.updateActiveFaults(
                  account,
                  Rules.faultBaseline(0, now),
                  now,
                  Rules.faultBaseline(store.prefs.getLong("baselineFrom", 0), now),
                  List.of());
            List<Rules.Event> events = data.events();
            runOnUiThread(
                () -> {
                  if (isFinishing() || !store.account().equals(account)
                      || !(page.equals("crossingHistory") ? historyDay : selected).equals(day)) return;
                  refreshContent();
                  Toast.makeText(this, "Đã tải " + events.size() + " bản ghi", Toast.LENGTH_SHORT)
                      .show();
                });
          } catch (Exception e) {
            runOnUiThread(
                () -> {
                  if (!isFinishing() && store.account().equals(account)
                      && (page.equals("crossingHistory") ? historyDay : selected).equals(day))
                    new AlertDialog.Builder(this)
                        .setTitle("Chưa tải được dữ liệu")
                        .setMessage(e.getMessage())
                        .setPositiveButton("Đóng", null)
                        .show();
                });
          } finally {
            runOnUiThread(() -> loadingDays.remove(request));
          }
        });
  }

  private EditText field(LinearLayout parent, String title, String hint, String value, int type) {
    parent.addView(text(title, 10, MUTED, true));
    gap(parent, 6);
    EditText f = new EditText(this);
    f.setSingleLine(true);
    f.setTextSize(13);
    f.setTextColor(INK);
    f.setHintTextColor(0xFF75849B);
    f.setInputType(type);
    f.setHint(hint);
    f.setText(value);
    f.setPadding(dp(12), dp(11), dp(12), dp(11));
    f.setBackground(shape(BG, 8, LINE));
    parent.addView(f, new LinearLayout.LayoutParams(-1, dp(44)));
    gap(parent, 12);
    return f;
  }

  private Switch toggle(String title, String description, boolean value, LinearLayout parent) {
    LinearLayout row = row();
    LinearLayout words = column();
    words.addView(text(title, 13, INK, true));
    if (!description.isEmpty()) {
      gap(words, 5);
      words.addView(text(description, 10, MUTED, false));
    }
    row.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
    Switch sw = new Switch(this);
    sw.setChecked(value);
    sw.setThumbTintList(
        new ColorStateList(
            new int[][] {new int[] {android.R.attr.state_checked}, new int[] {}},
            new int[] {BLUE, MUTED}));
    sw.setTrackTintList(
        new ColorStateList(
            new int[][] {new int[] {android.R.attr.state_checked}, new int[] {}},
            new int[] {0xFF216386, LINE}));
    sw.setContentDescription(title);
    row.addView(sw);
    parent.addView(row);
    return sw;
  }

  private void applyMonitoringDate(LocalDate day) {
    boolean automatic = day.equals(LocalDate.now(WebSource.ZONE));
    store.prefs.edit().putString("monitorDate", automatic ? "" : day.toString())
        .remove("historyReadDay").remove("historyReadAt")
        .putString("status", automatic ? "Đang đọc ngày hiện tại…" : "Đang tải ngày đã chọn…").apply();
    selected = historyDay = day;
    followToday = historyFollowToday = automatic;
    invalidateViewData();
    if (!store.prefs.getString("url", "").isEmpty() && !store.prefs.getString("user", "").isEmpty())
      startForegroundService(new Intent(this, MonitorService.class).setAction("RESTART"));
    render();
  }

  private void limitHistoryDates(DatePickerDialog picker) {
    LocalDate today = LocalDate.now(WebSource.ZONE);
    // DatePicker interprets epoch limits in the device zone; keep its calendar labels
    // aligned with Vietnamese dates even when the device uses another time zone.
    java.time.ZoneId deviceZone = java.time.ZoneId.systemDefault();
    picker.getDatePicker().setMinDate(today.minusDays(29).atStartOfDay(deviceZone).toInstant().toEpochMilli());
    picker.getDatePicker().setMaxDate(today.atTime(23, 59, 59).atZone(deviceZone).toInstant().toEpochMilli());
  }

  private void chooseMonitoringDate() {
    LocalDate initial = store.monitoringDay();
    DatePickerDialog picker = new DatePickerDialog(this,
        (v, year, month, day) -> applyMonitoringDate(LocalDate.of(year, month + 1, day)),
        initial.getYear(), initial.getMonthValue() - 1, initial.getDayOfMonth());
    limitHistoryDates(picker);
    picker.show();
  }

  private void settings() {
    String[] range = {rangeFrom(), rangeTo()};
    LinearLayout dates = card(SURFACE);
    sectionHeading(dates, "Ngày theo dõi", "calendar");
    TextView dateChoice = pill(store.monitoringDay().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        + (store.historicalMonitoring() ? " · Lịch sử  ▾" : " · Hôm nay (tự động)  ▾"), BLUE, TINT);
    dateChoice.setContentDescription("Chọn ngày tháng theo dõi");
    touch(dateChoice, this::chooseMonitoringDate);
    dates.addView(dateChoice);
    if (store.historicalMonitoring()) {
      gap(dates, 6);
      dates.addView(text("Đang xem ngày cũ · Không phát chuông lịch sử", 10, MUTED, false));
      dates.addView(action("Về hôm nay · Tự đổi ngày", null, false,
          () -> applyMonitoringDate(LocalDate.now(WebSource.ZONE))));
    }
    content.addView(dates);
    LinearLayout scope = card(SURFACE);
    sectionHeading(scope, "Phạm vi theo dõi", "direction");
    String[] rangeLabels = {"Từ đường ngang", "Đến đường ngang"};
    LinearLayout rangeRow = row();
    for (int i = 0; i < 2; i++) {
      final int index = i;
      LinearLayout entry = column();
      entry.addView(text(rangeLabels[i], 10, MUTED, false));
      gap(entry, 6);
      TextView choice =
          pill(range[i].isEmpty() ? "Chưa có danh sách" : "Km " + range[i] + "  ▾", BLUE, TINT);
      touch(
          choice,
          () -> {
            if (route().crossings().isEmpty()) {
              Toast.makeText(
                      this, "Kết nối tài khoản để đọc danh sách đường ngang", Toast.LENGTH_LONG)
                  .show();
              return;
            }
            String[] names = new String[route().crossings().size()];
            for (int j = 0; j < names.length; j++) names[j] = "Km " + route().crossings().get(j);
            new AlertDialog.Builder(this)
                .setTitle(rangeLabels[index])
                .setSingleChoiceItems(
                    names,
                    route().crossings().indexOf(range[index]),
                    (dialog, which) -> {
                      range[index] = route().crossings().get(which);
                      choice.setText("Km " + range[index] + "  ▾");
                      dialog.dismiss();
                    })
                .setNegativeButton("Đóng", null)
                .show();
          });
      entry.addView(choice);
      LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1);
      params.rightMargin = dp(i == 0 ? 8 : 0);
      rangeRow.addView(entry, params);
    }
    scope.addView(rangeRow);
    gap(scope, 10);
    scope.addView(
        action(
            "Áp dụng phạm vi",
            null,
            false,
            () -> {
              if (applyScope(range[0], range[1])) navigate("overview");
            }));
    content.addView(scope);
    LinearLayout account = card(SURFACE);
    sectionHeading(account, "Máy chủ & Tài khoản", "link");
    EditText url =
        field(
            account,
            "ĐỊA CHỈ WEBSITE",
            "http://…",
            store.prefs.getString("url", "http://"),
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
    EditText user =
        field(
            account,
            "ID ĐĂNG NHẬP",
            "Nhập tài khoản",
            store.prefs.getString("user", ""),
            InputType.TYPE_CLASS_TEXT);
    EditText pass =
        field(
            account,
            "MẬT KHẨU",
            store.prefs.contains("password") ? "Để trống để giữ mật khẩu đã lưu" : "Nhập mật khẩu",
            "",
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    TextView reveal = text("Hiện mật khẩu", 11, BLUE, true);
    reveal.setGravity(Gravity.END);
    touch(
        reveal,
        () -> {
          boolean visible =
              pass.getInputType()
                  == (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
          pass.setInputType(
              InputType.TYPE_CLASS_TEXT
                  | (visible
                      ? InputType.TYPE_TEXT_VARIATION_PASSWORD
                      : InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD));
          pass.setSelection(pass.length());
          reveal.setText(visible ? "Hiện mật khẩu" : "Ẩn mật khẩu");
        });
    account.addView(reveal);
    content.addView(account);
    LinearLayout options = card(SURFACE);
    sectionHeading(options, "Theo dõi & Báo động", "bell");
    options.addView(text("CHU KỲ ĐỌC DỮ LIỆU", 10, MUTED, true));
    gap(options, 10);
    options.addView(text("Cố định 30 giây", 12, INK, true));
    divider(options);
    options.addView(text("CÁCH CẢNH BÁO", 10, MUTED, true));
    RadioGroup alertModes = new RadioGroup(this);
    String[] modeValues = {AlertOptions.VOICE, AlertOptions.BELL, AlertOptions.SILENT};
    String[] modeLabels = {"Giọng nói", "Chỉ chuông", "Im lặng"};
    for (int i = 0; i < modeValues.length; i++) {
      RadioButton choice = new RadioButton(this);
      choice.setId(View.generateViewId());
      choice.setText(modeLabels[i]); choice.setTextColor(INK); choice.setTextSize(12);
      choice.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
      choice.setPadding(0, dp(6), 0, dp(6));
      choice.setTag(modeValues[i]);
      alertModes.addView(choice);
      if (store.alertMode().equals(modeValues[i])) alertModes.check(choice.getId());
    }
    alertModes.setOnCheckedChangeListener((group, id) -> {
      View selectedMode = group.findViewById(id);
      if (selectedMode != null) setAlertMode((String) selectedMode.getTag());
    });
    options.addView(alertModes);
    gap(options, 7);
    options.addView(text("Âm thanh dùng mức Báo thức của điện thoại", 10, MUTED, false));
    voiceState = text(store.prefs.getString("voiceStatus", "Giọng đọc sử dụng tiếng Việt của điện thoại"), 10, MUTED, false);
    options.addView(voiceState);
    options.addView(action("Cài đặt giọng đọc", "link", false, () -> {
      try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
      catch (android.content.ActivityNotFoundException missing) {
        Toast.makeText(this, "Mở Cài đặt điện thoại → Chuyển văn bản thành giọng nói", Toast.LENGTH_LONG).show();
      }
    }));
    gap(options, 10);
    options.addView(
        action(
            "Cài đặt chạy nền",
            "link",
            false,
            () ->
                startActivity(
                    new Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:" + getPackageName())))));
    gap(options, 7);
    options.addView(
        text(
            "Cho phép thông báo và chọn pin Không giới hạn để theo dõi khi khóa màn hình.",
            10,
            MUTED,
            false));
    content.addView(options);
    content.addView(
        action(
            "Lưu & bắt đầu theo dõi",
            "link",
            true,
            () -> {
              try {
                String endpoint = url.getText().toString().trim();
                var uri = java.net.URI.create(endpoint);
                if (!List.of("http", "https").contains(uri.getScheme())
                    || uri.getHost() == null
                    || uri.getUserInfo() != null)
                  throw new Exception("Nhập địa chỉ http:// hoặc https:// hợp lệ");
                String login = user.getText().toString().trim();
                if (login.isEmpty()) throw new Exception("Cần nhập ID đăng nhập");
                String secret = pass.getText().toString();
                boolean changed =
                    !endpoint.equals(store.prefs.getString("url", ""))
                        || !login.equals(store.prefs.getString("user", ""));
                if (secret.isEmpty() && !changed) secret = store.password();
                if (secret.isEmpty()) throw new Exception("Cần nhập mật khẩu cho tài khoản này");
                if (!changed
                    && !demo
                    && !route().crossings().isEmpty()
                    && !applyScope(range[0], range[1])) return;
                stopService(new Intent(this, MonitorService.class));
                store.credentials(endpoint, login, secret);
                store
                    .prefs
                    .edit()
                    .putInt("interval", Rules.POLL_SECONDS)
                    .putBoolean("demoUi", false)
                    .apply();
                demo = false;
                selected = historyDay = store.monitoringDay();
                followToday = historyFollowToday = !store.historicalMonitoring();
                startForegroundService(new Intent(this, MonitorService.class).setAction("RESTART"));
                navigate("overview");
              } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
              }
            }));
    gap(content, 10);
    content.addView(
        action(
            "Dừng theo dõi",
            null,
            false,
            () -> {
              stopService(new Intent(this, MonitorService.class));
              store.prefs.edit().putString("status", "Đã dừng theo dõi").apply();
              Toast.makeText(this, "Đã dừng theo dõi", Toast.LENGTH_SHORT).show();
            }));
  }

  private void openCrossing(String km) {
    detailDay = viewDay();
    detailFollowToday = !historicalView();
    selectedCrossing = Rules.km(km);
    navigate("detail");
  }

  private void sectionHeading(LinearLayout parent, String title, String kind) {
    LinearLayout heading = row();
    heading.addView(icon(kind, BLUE, 16));
    TextView label = text(title, 13, INK, true);
    label.setPadding(dp(7), 0, 0, 0);
    heading.addView(label);
    parent.addView(heading);
    gap(parent, 13);
  }

  private List<Rules.Event> crossingEvents(String km) {
    if (viewCrossingEvents == null) {
      viewCrossingEvents = new HashMap<>();
      for (var event : allToday())
        viewCrossingEvents
            .computeIfAbsent(Rules.km(event.crossing()), k -> new ArrayList<>())
            .add(event);
      for (var events : viewCrossingEvents.values())
        events.sort(Comparator.comparingLong(Rules.Event::at).reversed());
    }
    return viewCrossingEvents.getOrDefault(Rules.km(km), List.of());
  }

  private void crossingList() {
    LinearLayout introduction = row();
    int total = 0;
    for (String point : route().crossings()) if (inScope(point)) total++;
    introduction.addView(
        text("KHU VỰC THEO DÕI", 10, MUTED, true), new LinearLayout.LayoutParams(0, -2, 1));
    introduction.addView(pill(total + " đường ngang", BLUE, TINT));
    content.addView(introduction);
    gap(content, 8);
    int affected = 0;
    for (String point : route().crossings())
      if (inScope(point) && !faultsAt(point).isEmpty()) affected++;
    LinearLayout choices = row();
    String[] names = {"Tất cả", "Chưa ghi nhận lỗi", "Có lỗi"};
    int[] counts = {total, total - affected, affected};
    for (int i = 0; i < names.length; i++) {
      String name = names[i];
      boolean active = filter.equals(name);
      TextView choice = text(name + " (" + counts[i] + ")", 10, active ? BUTTON_TEXT : MUTED, true);
      choice.setGravity(Gravity.CENTER);
      choice.setPadding(dp(3), dp(11), dp(3), dp(11));
      choice.setBackground(shape(active ? BLUE : SURFACE, 8, 0));
      LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1);
      params.rightMargin = dp(i == 2 ? 0 : 4);
      choices.addView(choice, params);
      touch(
          choice,
          () -> {
            filter = name;
            render();
          });
    }
    content.addView(choices);
    gap(content, 8);
    int shown = 0;
    for (String point : route().points()) {
      if (Rules.isStation(point) || !inScope(point)) continue;
      List<Rules.Event> events = crossingEvents(point);
      List<Rules.Event> faults = faultsAt(point);
      boolean fault = !faults.isEmpty();
      if (filter.equals("Có lỗi") && !fault || filter.equals("Chưa ghi nhận lỗi") && fault)
        continue;
      shown++;
      LinearLayout list = card(fault ? FAULT : SURFACE);
      list.setPadding(0, 0, dp(10), 0);
      LinearLayout entry = row();
      entry.setMinimumHeight(dp(77));
      View stripe = new View(this);
      stripe.setBackgroundColor(fault ? DANGER : blend(BLUE, SURFACE, 0.8f));
      entry.addView(stripe, new LinearLayout.LayoutParams(dp(3), -1));
      LinearLayout words = column();
      words.setPadding(dp(11), dp(11), dp(6), dp(11));
      words.addView(text("Km " + point, 15, INK, true));
      gap(words, 6);
      TextView reading =
          text(
              events.isEmpty()
                  ? "Chưa có dữ liệu"
                  : fault ? faults.get(0).text() : "●  Chưa ghi nhận lỗi",
              11,
              events.isEmpty() ? MUTED : fault ? RED : GREEN,
              false);
      reading.setMaxLines(2);
      reading.setEllipsize(android.text.TextUtils.TruncateAt.END);
      words.addView(reading);
      entry.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
      entry.addView(text(events.isEmpty() ? "—" : time(events.get(0).at()), 11, MUTED, false));
      TextView more = text("  ›", 24, MUTED, false);
      entry.addView(more);
      touch(entry, () -> openCrossing(point));
      list.addView(entry);
      content.addView(list);
    }
    if (shown == 0) {
      LinearLayout emptyCard = card(SURFACE);
      empty(
          emptyCard,
          total == 0 ? "Chưa có danh sách" : "Không có đường ngang trong bộ lọc",
          "",
          "rail");
      content.addView(emptyCard);
    }
  }

  private String deviceReading(List<Rules.Event> faults, String group) {
    List<String> active = new ArrayList<>();
    for (Rules.Event fault : faults)
      if (Rules.deviceGroup(fault).equals(group))
        active.add(fault.text() + " · " + time(fault.at()));
    if (!active.isEmpty()) return String.join("\n", active);
    return demo || dayLoaded(viewDay()) && (historicalView()
        ? store.dayComplete(viewDay()) : displayedLastSuccess() > 0)
        ? "Tốt" : "Chưa tải đủ dữ liệu";
  }

  private void deviceRow(
      LinearLayout parent, String title, String value, String kind, boolean error) {
    LinearLayout r = new LinearLayout(this);
    r.setGravity(Gravity.TOP);
    boolean recovered = value.equals("Tốt") || value.toLowerCase(Locale.ROOT).contains("khôi phục tốt");
    r.addView(icon(kind, error ? RED : recovered ? GREEN : BLUE, 17));
    TextView name = text(title, 11, MUTED, false);
    name.setPadding(dp(9), 0, dp(8), 0);
    r.addView(name, new LinearLayout.LayoutParams(dp(108), -2));
    TextView status =
        text(
            value,
            11,
            error ? RED : recovered ? GREEN : value.equals("Chưa có dữ liệu") ? MUTED : INK,
            true);
    r.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
    parent.addView(r);
  }

  private void crossingDetail() {
    List<Rules.Event> events = crossingEvents(selectedCrossing);
    List<Rules.Event> faults = faultsAt(selectedCrossing);
    LinearLayout summary = card(SURFACE);
    LinearLayout top = row();
    top.addView(
        text("Km " + selectedCrossing, 22, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
    boolean resetBaseline = !demo && !historicalView() && store.prefs.getLong("baselineFrom", 0) > 0;
    String badge =
        !faults.isEmpty()
            ? "Đang có sự cố"
            : !demo && (!dayLoaded(viewDay()) || historicalView() && !store.dayComplete(viewDay()))
                ? "Chưa tải đủ dữ liệu"
                : resetBaseline
                ? "✓ Đã đặt lại"
                : events.isEmpty() ? "Chờ dữ liệu" : "✓ Chưa ghi nhận lỗi";
    int badgeColor = !faults.isEmpty() ? RED : events.isEmpty() && !resetBaseline ? MUTED : GREEN;
    top.addView(pill(badge, badgeColor, !faults.isEmpty() ? FAULT_TINT : GOOD));
    summary.addView(top);
    gap(summary, 9);
    summary.addView(
        text(
            events.isEmpty() ? "Chờ dữ liệu từ website" : "Cập nhật: " + time(events.get(0).at()),
            11,
            MUTED,
            false));
    gap(summary, 7);
    summary.addView(text("Thông tin ghi nhận gần nhất", 10, MUTED, false));
    divider(summary);
    String[] labels = {"Chuông", "Đèn", "Cần chắn", "Cảm biến", "Kết nối", "Điện áp"};
    String[] values = new String[labels.length];
    for (int i = 0; i < labels.length; i++) values[i] = deviceReading(faults, labels[i]);
    String[] icons = {"bell", "alert", "rail", "overview", "link", "voltage"};
    for (int i = 0; i < labels.length; i++) {
      final String value = values[i];
      boolean redReading = faults.stream().anyMatch(e -> value.contains(e.text()));
      deviceRow(summary, labels[i], value, icons[i], redReading);
      if (i < labels.length - 1) divider(summary);
    }
    content.addView(summary);
    axleFaultSummary(events, faults);
    LinearLayout history = card(SURFACE);
    history.addView(text("Lịch sử sự kiện gần nhất", 15, INK, true));
    gap(history, 18);
    if (events.isEmpty())
      empty(history, "Chưa có sự kiện", "Dữ liệu sẽ xuất hiện sau khi kết nối.", "history");
    for (int i = 0; i < Math.min(12, events.size()); i++) {
      if (i > 0) divider(history);
      Rules.Event e = events.get(i);
      eventRow(history, e, e.red());
      String note = Rules.axleNote(e);
      if (!note.isEmpty()) {
        gap(history, 10);
        history.addView(text(note, 11, MUTED, false));
      }
    }
    content.addView(history);
    history.addView(action("Chi tiết", "history", true, () -> {
      historyDay = viewDay();
      historyFollowToday = !historicalView();
      navigate("crossingHistory");
    }));
    gap(content, 17);
  }

  private void chooseHistoryDate(boolean crossing) {
    LocalDate initial = crossing ? historyDay : selected;
    LocalDate first = LocalDate.now(WebSource.ZONE).minusDays(29);
    if (initial.isBefore(first)) initial = first;
    DatePickerDialog picker = new DatePickerDialog(this, (v, year, month, day) -> {
      LocalDate chosen = LocalDate.of(year, month + 1, day);
      if (crossing) {
        historyDay = chosen;
        historyFollowToday = chosen.equals(LocalDate.now(WebSource.ZONE));
      } else {
        selected = chosen;
        followToday = chosen.equals(LocalDate.now(WebSource.ZONE));
      }
      render();
      if (!demo && !store.dayComplete(chosen)) loadHistory(chosen);
    }, initial.getYear(), initial.getMonthValue() - 1, initial.getDayOfMonth());
    limitHistoryDates(picker);
    picker.show();
  }

  private void crossingHistory() {
    LinearLayout controls = card(SURFACE);
    controls.addView(text("Km " + selectedCrossing, 18, INK, true));
    gap(controls, 10);
    LinearLayout date = row();
    TextView day = text(historyDay.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")), 13, BLUE, true);
    date.addView(day, new LinearLayout.LayoutParams(0, -2, 1));
    touch(day, () -> chooseHistoryDate(true));
    TextView load = pill("Tải dữ liệu", BLUE, TINT);
    touch(load, this::loadHistory);
    date.addView(load);
    controls.addView(date);
    gap(controls, 7);
    controls.addView(text("Lưu lịch sử 30 ngày, tính cả hôm nay", 10, MUTED, false));
    content.addView(controls);
    long from = historyDay.atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli();
    long to = historyDay.plusDays(1).atStartOfDay(WebSource.ZONE).toInstant().toEpochMilli();
    List<Rules.Event> records = new ArrayList<>();
    for (var event : demo ? samples() : dayData(historyDay).events())
      if (Rules.km(event.crossing()).equals(Rules.km(selectedCrossing))) records.add(event);
    List<Rules.EventGroup> groups = Rules.crossingHistory(records, selectedCrossing);
    String limitKey = dayKey(historyDay) + "|" + selectedCrossing;
    int limit = rowLimits.getOrDefault(limitKey, 20), rendered = 0;
    for (var group : groups) {
      if (rendered++ >= limit) break;
      LinearLayout frame = card(SURFACE);
      frame.setBackground(panel(SURFACE, LINE));
      String title = group.direction() > 0 ? "Tàu lẻ →"
          : group.direction() < 0 ? "Tàu chẵn ←" : "Sự kiện ngoài lượt tàu";
      frame.addView(text("Km " + group.crossing() + " · " + title, 13,
          group.direction() == 0 ? INK : GREEN, true));
      var rows = group.events();
      gap(frame, 5);
      frame.addView(text(time(rows.get(0).at()) + " – " + time(rows.get(rows.size() - 1).at()),
          10, MUTED, false));
      if (group.direction() != 0) {
        gap(frame, 5);
        frame.addView(text(group.completed() ? "Đã ghi nhận kết thúc lượt tàu" : "Chưa ghi nhận kết thúc",
            10, group.completed() ? GREEN : MUTED, false));
      }
      for (var event : rows) {
        divider(frame);
        LinearLayout line = row();
        line.setGravity(Gravity.TOP);
        line.addView(text(time(event.at()), 10, MUTED, false),
            new LinearLayout.LayoutParams(dp(66), -2));
        line.addView(text(event.text(), 11, event.red() ? RED : INK, false),
            new LinearLayout.LayoutParams(0, -2, 1));
        frame.addView(line);
        String note = Rules.axleNote(event);
        if (!note.isEmpty()) {
          gap(frame, 5);
          frame.addView(text(note, 10, MUTED, false));
        }
      }
      content.addView(frame);
    }
    if (groups.size() > limit)
      content.addView(action("Hiển thị thêm · " + Math.min(limit, groups.size()) + "/" + groups.size() + " nhóm sự kiện",
          "history", true, () -> { rowLimits.put(limitKey, limit + 20); refreshContent(); }));
    if (groups.isEmpty()) {
      LinearLayout none = card(SURFACE);
      empty(none, "Chưa có sự kiện trong ngày", "Chọn Tải dữ liệu để đọc từ website.", "history");
      content.addView(none);
    }
  }

  private void axleFaultSummary(List<Rules.Event> events, List<Rules.Event> faults) {
    Set<Integer> warned = new HashSet<>();
    for (var fault : faults) if (Rules.isAxleFault(fault)) warned.add(fault.id().charAt(5) - '0');
    if (warned.isEmpty()) return;
    Map<Integer, Rules.AxleError> latest = new TreeMap<>();
    for (var e : Rules.axleErrors(route(), events))
      if (warned.contains(e.sensor())) latest.put(e.sensor(), e);
    LinearLayout panel = card(SURFACE);
    panel.addView(text("Đếm trục lỗi", 15, INK, true));
    for (var e : latest.values()) {
      divider(panel);
      panel.addView(
          text("CB" + e.sensor() + " · " + e.dailyCount() + " lần lệch từ 3 trục", 12, RED, true));
      gap(panel, 5);
      panel.addView(
          text(
              "Gần nhất " + time(e.source().at()) + " · " + Rules.axleDifference(e.delta()),
              11,
              RED,
              false));
      panel.addView(
          text(
              "Tổng ghi nhận: thiếu " + e.missing() + ", thừa " + e.extra() + " trục",
              10,
              MUTED,
              false));
    }
    content.addView(panel);
  }

  private void navigation() {
    LinearLayout nav = row();
    nav.setPadding(dp(12), dp(5), dp(12), dp(5));
    nav.setBackground(shape(BG, 0, LINE));
    String[] pages = {"overview", "crossings", "incidents", "settings"},
        names = {"Tổng quan", "Đường ngang", "Sự cố", "Cài đặt"},
        icons = {"overview", "crossing", "incidentNav", "settings"};
    for (int i = 0; i < pages.length; i++) {
      String target = pages[i];
      boolean active =
          page.equals(target)
              || ((page.equals("detail") || page.equals("crossingHistory")) && target.equals("crossings"))
              || (page.equals("trains") && target.equals("overview"));
      LinearLayout tab = column();
      tab.setGravity(Gravity.CENTER);
      tab.setPadding(0, dp(5), 0, dp(4));
      View glyph = icon(icons[i], active ? BLUE : MUTED, 20);
      if (pages[i].equals("incidents")) incidentTabIcon = glyph;
      tab.addView(glyph);
      gap(tab, 5);
      TextView tabLabel = text(names[i], 9, active ? BLUE : MUTED, active);
      tabLabel.setGravity(Gravity.CENTER);
      tab.addView(tabLabel);
      if (active) tab.setBackground(panel(TINT, BLUE));
      nav.addView(tab, new LinearLayout.LayoutParams(0, dp(48), 1));
      touch(tab, () -> navigate(target));
    }
    screen.addView(nav);
  }

  private class RouteView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<String> points = route().points();
    private final int[] occupied = new int[points.size()];
    private final boolean[] lit = new boolean[points.size()];
    private List<Rules.TrackSegment> segments = List.of();

    RouteView() {
      super(MainActivity.this);
      updateOccupancy();
    }

    int preferredHeight() {
      // Empty diagrams need no upper label lanes. Keep the original space for trains.
      return dp(segments.isEmpty() ? 76 : 101);
    }

    void updateOccupancy() {
      Arrays.fill(occupied, 0);
      Rules.TravelState state = diagramState();
      segments = Rules.trackSegments(route(), state);
      for (Rules.Occupancy report : Rules.approachingCrossings(state)) {
        int index = points.indexOf(report.crossing());
        if (index >= 0) occupied[index] = report.direction();
      }
      var own = getLayoutParams();
      if (own != null && own.height != preferredHeight()) {
        own.height = preferredHeight();
        setLayoutParams(own);
      }
      if (getParent() instanceof HorizontalScrollView scroll) {
        var size = scroll.getLayoutParams();
        if (size != null && size.height != preferredHeight() + dp(4)) {
          size.height = preferredHeight() + dp(4);
          scroll.setLayoutParams(size);
        }
      }
      invalidate();
    }

    @Override
    public boolean onTouchEvent(android.view.MotionEvent event) {
      if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
        if (points.isEmpty()) return true;
        float step = points.size() > 1 ? (getWidth() - dp(60)) / (float) (points.size() - 1) : 1;
        int index =
            points.size() == 1
                ? 0
                : Math.max(
                    0, Math.min(points.size() - 1, Math.round((event.getX() - dp(25)) / step)));
        String point = points.get(index);
        if (Rules.isStation(point)) {
          Toast.makeText(MainActivity.this, "Ga " + Rules.stationLabel(point), Toast.LENGTH_SHORT)
              .show();
        } else openCrossing(point);
        performClick();
        return true;
      }
      return true;
    }

    @Override
    public boolean performClick() {
      super.performClick();
      return true;
    }

    @Override
    protected void onDraw(Canvas c) {
      super.onDraw(c);
      if (points.isEmpty()) {
        p.setColor(MUTED);
        p.setTextSize(dp(11));
        c.drawText("Đang chờ danh sách tuyến từ web", dp(7), dp(38), p);
        return;
      }
      float left = points.size() == 1 ? getWidth() / 2f : dp(25),
          right = points.size() == 1 ? left : getWidth() - dp(35),
          step = points.size() > 1 ? (right - left) / (points.size() - 1) : 0,
          y = dp(segments.isEmpty() ? 25 : 50);
      p.setStrokeCap(Paint.Cap.ROUND);
      p.setStrokeWidth(dp(3));
      p.setColor(LINE);
      c.drawLine(left - dp(20), y, right + dp(20), y, p);
      int reportColor = GREEN;
      Arrays.fill(lit, false);
      List<float[]> labels = new ArrayList<>();
      p.setColor(reportColor);
      p.setStrokeWidth(dp(5));
      p.setStrokeCap(Paint.Cap.BUTT);
      for (Rules.TrackSegment leg : segments) {
        float[] ends = segmentEnds(leg, left, right, step);
        if (ends == null) continue;
        float x1 = ends[0], x2 = ends[1];
        p.setColor(reportColor);
        // Static halo: redraw only with new data, never simulate a train moving by a timer.
        p.setAlpha(22);
        p.setStrokeWidth(dp(12));
        c.drawLine(Math.min(x1, x2), y, Math.max(x1, x2), y, p);
        p.setAlpha(55);
        p.setStrokeWidth(dp(8));
        c.drawLine(Math.min(x1, x2), y, Math.max(x1, x2), y, p);
        p.setAlpha(255);
        p.setStrokeWidth(dp(5));
        p.setStrokeCap(Paint.Cap.BUTT);
        c.drawLine(Math.min(x1, x2), y, Math.max(x1, x2), y, p);
        int a = leg.from() == null ? -1 : points.indexOf(leg.from()),
            b = leg.to() == null ? -1 : points.indexOf(leg.to());
        if (a >= 0) lit[a] = true;
        if (b >= 0) lit[b] = true;
      }
      for (Rules.TrackSegment leg : segments) {
        float[] ends = segmentEnds(leg, left, right, step);
        if (ends != null)
          drawDirection(c, labels, (ends[0] + ends[1]) / 2f, y, leg.direction(), reportColor);
      }
      for (int i = 0; i < points.size(); i++) {
        float x = left + step * i;
        String km = points.get(i);
        boolean station = Rules.isStation(km);
        p.setStyle(Paint.Style.FILL);
        p.setColor(SURFACE);
        c.drawCircle(x, y, dp(5.5f), p);
        p.setColor(station ? WARNING : lit[i] ? reportColor : 0xFF63728F);
        if (station) c.drawRoundRect(x - dp(4), y - dp(4), x + dp(4), y + dp(4), dp(2), dp(2), p);
        else c.drawCircle(x, y, dp(3.5f), p);
        p.setTypeface(
            Typeface.create(station ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        p.setTextSize(dp(station ? 9 : 8.5f));
        p.setColor(station ? WARNING : lit[i] ? reportColor : MUTED);
        if (station) {
          String name = "Ga " + Rules.stationLabel(km);
          c.drawText(name, x - p.measureText(name) / 2, y + dp(17), p);
        } else {
          c.save();
          c.translate(x - dp(2), y + dp(14));
          c.rotate(57);
          c.drawText(km, 0, 0, p);
          c.restore();
        }
      }
    }

    private float[] segmentEnds(Rules.TrackSegment leg, float left, float right, float step) {
      int from = points.indexOf(leg.from()), to = points.indexOf(leg.to());
      if (leg.from() == null) {
        if (to != 0 && to != points.size() - 1) return null;
        float end = left + step * to;
        return new float[] {end - leg.direction() * dp(20), end};
      }
      if (leg.to() == null) {
        if (from != 0 && from != points.size() - 1) return null;
        float start = left + step * from;
        return new float[] {start, start + leg.direction() * dp(20)};
      }
      if (from < 0 || to < 0 || Math.abs(from - to) != 1) return null;
      return new float[] {left + step * from, left + step * to};
    }

    private void drawDirection(
        Canvas c, List<float[]> labels, float ax, float y, int direction, int color) {
      p.setStyle(Paint.Style.FILL);
      p.setColor(color);
      p.setStrokeWidth(dp(1.7f));
      p.setStrokeCap(Paint.Cap.ROUND);
      p.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
      boolean compact = segments.size() > 4;
      p.setTextSize(dp(compact ? 8 : 9));
      String name =
          (direction > 0 ? (compact ? "Lẻ →" : "Tàu lẻ →") : (compact ? "Chẵn ←" : "Tàu chẵn ←"));
      float half = p.measureText(name) / 2;
      float center = Math.max(half + dp(1), Math.min(getWidth() - half - dp(1), ax));
      int lane = 0;
      boolean collision;
      do {
        collision = false;
        for (float[] label : labels)
          if ((int) label[2] == lane && Math.abs(label[0] - center) < label[1] + half + dp(3)) {
            lane++;
            collision = true;
            break;
          }
      } while (collision);
      float baseline = y - dp(8 + lane * 11);
      labels.add(new float[] {center, half, lane, baseline + p.ascent(), baseline + p.descent()});
      p.setColor(blend(color, SURFACE, 0.88f));
      c.drawRoundRect(
          center - half - dp(3),
          baseline + p.ascent() - dp(2),
          center + half + dp(3),
          baseline + p.descent() + dp(2),
          dp(3),
          dp(3),
          p);
      p.setColor(color);
      c.drawText(name, center - half, baseline, p);
    }
  }

  /** Small consistent line icons, drawn locally without image/network dependencies. */
  private class Icon extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String kind;
    private final int color;

    Icon(String k, int c) {
      super(MainActivity.this);
      kind = k;
      color = c;
      setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    protected void onDraw(Canvas canvas) {
      super.onDraw(canvas);
      canvas.save();
      canvas.scale(getWidth() / 24f, getHeight() / 24f);
      p.setColor(color);
      p.setStyle(Paint.Style.STROKE);
      p.setStrokeWidth(1.65f);
      p.setStrokeCap(Paint.Cap.ROUND);
      p.setStrokeJoin(Paint.Join.ROUND);
      switch (kind) {
        case "crossing":
          canvas.drawLine(6, 5, 18, 19, p);
          canvas.drawLine(18, 5, 6, 19, p);
          canvas.drawLine(12, 12, 12, 23, p);
          canvas.drawLine(7, 4, 4, 7, p);
          canvas.drawLine(17, 4, 20, 7, p);
          break;
        case "rail":
          canvas.drawLine(8, 3, 5, 21, p);
          canvas.drawLine(16, 3, 19, 21, p);
          for (int y = 5; y < 22; y += 5) canvas.drawLine(7, y, 17, y, p);
          break;
        case "overview":
          for (int x = 4; x <= 14; x += 10)
            for (int y = 4; y <= 14; y += 10)
              canvas.drawRoundRect(x, y, x + 6, y + 6, 1.5f, 1.5f, p);
          break;
        case "settings":
          canvas.drawCircle(12, 12, 6.5f, p);
          canvas.drawCircle(12, 12, 2.4f, p);
          for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            canvas.drawLine(
                12 + (float) Math.cos(a) * 7,
                12 + (float) Math.sin(a) * 7,
                12 + (float) Math.cos(a) * 9.5f,
                12 + (float) Math.sin(a) * 9.5f,
                p);
          }
          break;
        case "history":
          canvas.drawArc(4, 4, 21, 21, -140, 290, false, p);
          canvas.drawLine(4, 3, 4, 9, p);
          canvas.drawLine(4, 9, 10, 9, p);
          canvas.drawLine(12, 8, 12, 13, p);
          canvas.drawLine(12, 13, 16, 15, p);
          break;
        case "direction":
          canvas.drawLine(4, 9, 20, 9, p);
          canvas.drawLine(16, 5, 20, 9, p);
          canvas.drawLine(16, 13, 20, 9, p);
          canvas.drawLine(20, 17, 4, 17, p);
          canvas.drawLine(8, 13, 4, 17, p);
          canvas.drawLine(8, 21, 4, 17, p);
          break;
        case "incidentNav":
        case "alert":
          Path triangle = new Path();
          triangle.moveTo(12, 3);
          triangle.lineTo(22, 20);
          triangle.lineTo(2, 20);
          triangle.close();
          canvas.drawPath(triangle, p);
          canvas.drawLine(12, 9, 12, 13, p);
          canvas.drawPoint(12, 17, p);
          if (kind.equals("incidentNav") && navHasFault) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(DANGER);
            canvas.drawCircle(20, 4, 2.8f, p);
          }
          break;
        case "bell":
        case "mute":
          canvas.drawArc(6, 4, 18, 19, 180, 180, false, p);
          canvas.drawLine(6, 11, 6, 16, p);
          canvas.drawLine(18, 11, 18, 16, p);
          canvas.drawLine(4, 18, 20, 18, p);
          canvas.drawArc(9, 18, 15, 23, 15, 150, false, p);
          if (kind.equals("mute")) canvas.drawLine(3, 3, 21, 21, p);
          break;
        case "down":
          canvas.drawLine(6, 9, 12, 15, p);
          canvas.drawLine(12, 15, 18, 9, p);
          break;
        case "up":
          canvas.drawLine(6, 15, 12, 9, p);
          canvas.drawLine(12, 9, 18, 15, p);
          break;
        case "back":
          canvas.drawLine(5, 12, 20, 12, p);
          canvas.drawLine(5, 12, 11, 6, p);
          canvas.drawLine(5, 12, 11, 18, p);
          break;
        case "close":
          canvas.drawLine(6, 6, 18, 18, p);
          canvas.drawLine(18, 6, 6, 18, p);
          break;
        case "voltage":
          Path bolt = new Path();
          bolt.moveTo(14, 2);
          bolt.lineTo(5, 14);
          bolt.lineTo(11, 14);
          bolt.lineTo(10, 22);
          bolt.lineTo(20, 9);
          bolt.lineTo(13, 9);
          bolt.close();
          canvas.drawPath(bolt, p);
          break;
        case "calendar":
          canvas.drawRoundRect(4, 5, 20, 21, 3, 3, p);
          canvas.drawLine(4, 10, 20, 10, p);
          canvas.drawLine(8, 3, 8, 7, p);
          canvas.drawLine(16, 3, 16, 7, p);
          canvas.drawPoint(9, 15, p);
          canvas.drawPoint(15, 15, p);
          break;
        case "download":
          canvas.drawLine(12, 3, 12, 15, p);
          canvas.drawLine(7, 10, 12, 15, p);
          canvas.drawLine(12, 15, 17, 10, p);
          canvas.drawLine(4, 16, 4, 21, p);
          canvas.drawLine(4, 21, 20, 21, p);
          canvas.drawLine(20, 21, 20, 16, p);
          break;
        case "shield":
          Path shield = new Path();
          shield.moveTo(12, 3);
          shield.lineTo(20, 6);
          shield.lineTo(19, 15);
          shield.quadTo(16, 20, 12, 22);
          shield.quadTo(8, 20, 5, 15);
          shield.lineTo(4, 6);
          shield.close();
          canvas.drawPath(shield, p);
          canvas.drawLine(8, 12, 11, 15, p);
          canvas.drawLine(11, 15, 16, 9, p);
          break;
        default:
          canvas.drawArc(3, 7, 14, 17, 90, 240, false, p);
          canvas.drawArc(10, 7, 21, 17, -90, 240, false, p);
          canvas.drawLine(8, 12, 16, 12, p);
      }
      canvas.restore();
    }
  }
}
