Nguồn Android nguyên byte tại commit ee1affe5ea024590ce356e0f1e23aafbf17df669.
Java core độc lập: Rules.java, WebSource.java, AlertOptions.java.
Các file Activity/Service/Store/Voice là tham chiếu Android, không chạy trực tiếp trong Safari.
run-reference-tests.sh cần Python 3, curl và JDK 21; tải jsoup 1.18.3 có kiểm SHA-256.
Test Android instrumentation cần Android, chỉ đưa vào để đối chiếu hành vi.
Tài liệu history ưu tiên thấp hơn đặc tả chính; không khôi phục yêu cầu cũ.
