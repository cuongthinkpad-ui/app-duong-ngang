Ảnh lịch sử từ các bài kiểm thử fixture, dùng đối chiếu phong cách/chi tiết.
Không phải ảnh tài khoản vận hành. Ảnh cũ chưa có mọi thay đổi 0.27.3.
Bố cục/nút/chu kỳ/ngày cuối cùng phải theo đặc tả chính, không theo ảnh cũ.
